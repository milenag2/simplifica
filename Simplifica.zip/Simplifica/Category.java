package com.expensetracker;

/**
 * Category - Modelo de dados para representar uma categoria de transação
 * 
 * Esta classe encapsula os dados de uma categoria utilizada para
 * organizar e classificar as transações financeiras do usuário.
 * 
 * Atributos:
 * - ID único da categoria
 * - ID do usuário proprietário
 * - Nome da categoria
 * - Tipo da categoria (income/expense)
 */
public class Category {
    
    // Constantes para tipos de categoria
    public static final String TYPE_INCOME = "income";
    public static final String TYPE_EXPENSE = "expense";
    
    // Atributos da categoria
    private int id;
    private int userId;
    private String name;
    private String type;
    
    /**
     * Construtor padrão
     */
    public Category() {
    }
    
    /**
     * Construtor com parâmetros
     * 
     * @param name Nome da categoria
     * @param type Tipo da categoria (income/expense)
     */
    public Category(String name, String type) {
        this.name = name;
        this.type = type;
    }
    
    /**
     * Construtor completo
     * 
     * @param id ID da categoria
     * @param userId ID do usuário
     * @param name Nome da categoria
     * @param type Tipo da categoria
     */
    public Category(int id, int userId, String name, String type) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.type = type;
    }
    
    // Getters e Setters
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    // Métodos auxiliares
    
    /**
     * Verifica se a categoria é do tipo receita
     * 
     * @return true se for receita, false caso contrário
     */
    public boolean isIncomeType() {
        return TYPE_INCOME.equals(type);
    }
    
    /**
     * Verifica se a categoria é do tipo despesa
     * 
     * @return true se for despesa, false caso contrário
     */
    public boolean isExpenseType() {
        return TYPE_EXPENSE.equals(type);
    }
    
    /**
     * Retorna a descrição do tipo em português
     * 
     * @return "Receita" ou "Despesa"
     */
    public String getTypeDescription() {
        if (isIncomeType()) {
            return "Receita";
        } else if (isExpenseType()) {
            return "Despesa";
        } else {
            return type;
        }
    }
    
    /**
     * Valida se os dados da categoria estão corretos
     * 
     * @return true se válida, false caso contrário
     */
    public boolean isValid() {
        // Verifica se o nome não está vazio
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        
        // Verifica se o tipo é válido
        if (type == null || (!TYPE_INCOME.equals(type) && !TYPE_EXPENSE.equals(type))) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Cria uma cópia da categoria
     * 
     * @return Nova instância com os mesmos dados
     */
    public Category copy() {
        Category copy = new Category();
        copy.id = this.id;
        copy.userId = this.userId;
        copy.name = this.name;
        copy.type = this.type;
        
        return copy;
    }
    
    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Category category = (Category) obj;
        return id == category.id;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}

