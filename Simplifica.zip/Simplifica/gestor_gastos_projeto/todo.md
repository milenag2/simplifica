## Tarefas para o aplicativo de gestão de gastos

### Fase 1: Planejamento e design da arquitetura do sistema
- [ ] Definir a arquitetura geral do sistema (backend, frontend web, aplicativo Android).
- [ ] Detalhar o modelo de dados para gastos, receitas, categorias e recorrências.
- [ ] Definir as APIs RESTful para comunicação entre o frontend e o backend.

### Fase 2: Desenvolvimento do backend API com Flask
- [x] Configurar o ambiente Flask.
- [x] Implementar o modelo de dados com um ORM (ex: SQLAlchemy).
- [x] Criar endpoints para adicionar/listar/atualizar/deletar gastos e receitas.
- [x] Criar endpoints para gerenciar categorias.
- [x] Criar endpoints para gerenciar despesas/receitas recorrentes.
- [x] Implementar lógica para cálculo de saldo mensal.
- [x] Implementar lógica para geração de relatórios (diários, mensais, anuais).

### Fase 3: Desenvolvimento da aplicação web frontend
- [x] Configurar o ambiente de desenvolvimento web (HTML, CSS, JavaScript).
- [x] Criar a interface de usuário para adicionar/visualizar gastos e receitas.
- [x] Implementar a exibição do saldo mensal.
- [x] Desenvolver a interface para categorização e visualização de gráficos.
- [x] Criar a interface para visualização de relatórios.
- [x] Implementar a funcionalidade de despesas/receitas recorrentes.
- [x] Conectar o frontend com o backend via APIs.

### Fase 4: Desenvolvimento do aplicativo Android
- [x] Configurar o ambiente de desenvolvimento Android (Java).
- [x] Criar a estrutura básica do aplicativo (MainActivity, fragmentos).
- [x] Implementar modelos de dados (Transaction, Category, BalanceResponse).
- [x] Desenvolver o gerenciador de API (ApiManager) para comunicação com backend.
- [x] Criar adaptadores para listas (TransactionAdapter).
- [x] Implementar o fragmento de dashboard com resumo financeiro.
- [x] Criar fragmentos para transações, categorias e relatórios.
- [ ] Implementar telas de adicionar/editar transações e categorias.
- [ ] Adicionar suporte a transações recorrentes.
- [ ] Criar layouts responsivos e interface amigável.

### Fase 5: Implementação de gráficos e relatórios
- [ ] Integrar bibliotecas de gráficos (ex: Chart.js para web, MPAndroidChart para Android).
- [ ] Gerar gráficos de categorização (pizza, barras).
- [ ] Gerar gráficos de relatórios (linhas, barras).

### Fase 6: Testes e integração do sistema completo
- [ ] Realizar testes unitários para o backend, frontend web e aplicativo Android.
- [ ] Realizar testes de integração entre os componentes.
- [ ] Testar a funcionalidade de despesas/receitas recorrentes.
- [ ] Testar a geração e exibição de gráficos e relatórios.

### Fase 7: Deploy e entrega dos resultados ao usuário
- [ ] Preparar o backend para deploy.
- [ ] Preparar o frontend web para deploy.
- [ ] Preparar o aplicativo Android para deploy (gerar APK).
- [ ] Fornecer instruções detalhadas para o usuário sobre como configurar e usar o sistema.


