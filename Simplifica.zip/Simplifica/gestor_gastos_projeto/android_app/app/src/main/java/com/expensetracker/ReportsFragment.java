package com.expensetracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.Calendar;

/**
 * ReportsFragment - Fragmento para visualizar relatórios financeiros
 * 
 * Este fragmento permite ao usuário visualizar relatórios detalhados
 * sobre suas finanças, incluindo gráficos e análises.
 * 
 * Funcionalidades:
 * - Relatórios mensais e anuais
 * - Gráficos por categoria
 * - Análise de tendências
 * - Filtros por período
 * - Exportação de dados
 */
public class ReportsFragment extends Fragment {
    
    // Elementos da interface
    private Spinner monthSpinner;
    private Spinner yearSpinner;
    private Button generateReportButton;
    private TextView reportSummaryText;
    private View chartContainer;
    private View reportContentView;
    private View emptyStateView;
    
    // Gerenciador de API
    private ApiManager apiManager;
    
    // Dados do relatório atual
    private int selectedMonth;
    private int selectedYear;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reports, container, false);
        
        // Inicializa os componentes
        initializeViews(view);
        setupSpinners();
        setupClickListeners();
        
        // Inicializa o gerenciador de API
        apiManager = new ApiManager(getContext());
        
        // Define o mês e ano atuais como padrão
        Calendar calendar = Calendar.getInstance();
        selectedMonth = calendar.get(Calendar.MONTH) + 1; // Calendar.MONTH é 0-based
        selectedYear = calendar.get(Calendar.YEAR);
        
        return view;
    }
    
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        // Carrega o relatório inicial
        generateReport();
    }
    
    /**
     * Inicializa as referências dos elementos da interface
     */
    private void initializeViews(View view) {
        monthSpinner = view.findViewById(R.id.month_spinner);
        yearSpinner = view.findViewById(R.id.year_spinner);
        generateReportButton = view.findViewById(R.id.generate_report_button);
        reportSummaryText = view.findViewById(R.id.report_summary_text);
        chartContainer = view.findViewById(R.id.chart_container);
        reportContentView = view.findViewById(R.id.report_content_view);
        emptyStateView = view.findViewById(R.id.empty_state_view);
    }
    
    /**
     * Configura os spinners de mês e ano
     */
    private void setupSpinners() {
        // TODO: Implementar adaptadores para os spinners
        // Por enquanto, deixa os spinners vazios
    }
    
    /**
     * Configura os listeners de clique
     */
    private void setupClickListeners() {
        generateReportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateReport();
            }
        });
    }
    
    /**
     * Gera o relatório baseado nos filtros selecionados
     */
    private void generateReport() {
        showLoading(true);
        
        // TODO: Implementar chamada para API de relatórios
        // Por enquanto, simula um relatório
        simulateReportGeneration();
    }
    
    /**
     * Simula a geração de um relatório (placeholder)
     */
    private void simulateReportGeneration() {
        // Simula um delay de carregamento
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000); // Simula 2 segundos de carregamento
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showMockReport();
                            showLoading(false);
                        }
                    });
                }
            }
        }).start();
    }
    
    /**
     * Exibe um relatório simulado
     */
    private void showMockReport() {
        String reportText = "Relatório Mensal - " + getMonthName(selectedMonth) + "/" + selectedYear + "\n\n" +
                "📈 Receitas: R$ 3.500,00\n" +
                "📉 Despesas: R$ 2.800,00\n" +
                "💰 Saldo: R$ 700,00\n\n" +
                "Principais Categorias:\n" +
                "• Alimentação: R$ 800,00\n" +
                "• Transporte: R$ 400,00\n" +
                "• Lazer: R$ 300,00\n" +
                "• Outros: R$ 1.300,00\n\n" +
                "📊 Taxa de economia: 20%\n" +
                "📈 Variação em relação ao mês anterior: +5%";
        
        reportSummaryText.setText(reportText);
        showReportContent(true);
    }
    
    /**
     * Retorna o nome do mês baseado no número
     */
    private String getMonthName(int month) {
        String[] months = {
                "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
        };
        
        if (month >= 1 && month <= 12) {
            return months[month - 1];
        }
        return "Mês inválido";
    }
    
    /**
     * Mostra/esconde o indicador de loading
     */
    private void showLoading(boolean show) {
        if (show) {
            generateReportButton.setText("Gerando...");
            generateReportButton.setEnabled(false);
        } else {
            generateReportButton.setText(R.string.generate_report);
            generateReportButton.setEnabled(true);
        }
    }
    
    /**
     * Mostra/esconde o conteúdo do relatório
     */
    private void showReportContent(boolean show) {
        if (show) {
            reportContentView.setVisibility(View.VISIBLE);
            emptyStateView.setVisibility(View.GONE);
        } else {
            reportContentView.setVisibility(View.GONE);
            emptyStateView.setVisibility(View.VISIBLE);
        }
    }
    
    /**
     * Exibe uma mensagem de erro
     */
    private void showError(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }
    
    /**
     * Método público para atualizar os relatórios
     */
    public void refreshReports() {
        generateReport();
    }
    
    /**
     * Método chamado quando o fragmento fica visível
     */
    @Override
    public void onResume() {
        super.onResume();
        // Pode atualizar os relatórios quando necessário
    }
    
    /**
     * Limpa recursos quando o fragmento é destruído
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (apiManager != null) {
            apiManager.shutdown();
        }
    }
}

