package com.expensetracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.util.ArrayList;
import java.util.List;

/**
 * TransactionsFragment - Fragmento para gerenciar transações
 * 
 * Este fragmento permite ao usuário visualizar, adicionar, editar e excluir
 * transações financeiras (receitas e despesas).
 * 
 * Funcionalidades:
 * - Lista completa de transações
 * - Filtros por tipo e categoria
 * - Ações de adicionar, editar e excluir
 * - Atualização por pull-to-refresh
 * - Suporte a transações recorrentes
 */
public class TransactionsFragment extends Fragment {
    
    // Elementos da interface
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView transactionsList;
    private Button addTransactionButton;
    private View emptyStateView;
    
    // Adaptador para a lista de transações
    private TransactionAdapter transactionsAdapter;
    
    // Gerenciador de API
    private ApiManager apiManager;
    
    // Lista de transações
    private List<Transaction> transactions;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_transactions, container, false);
        
        // Inicializa os componentes
        initializeViews(view);
        setupRecyclerView();
        setupSwipeRefresh();
        setupClickListeners();
        
        // Inicializa o gerenciador de API
        apiManager = new ApiManager(getContext());
        
        // Inicializa a lista de transações
        transactions = new ArrayList<>();
        
        return view;
    }
    
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        // Carrega as transações
        loadTransactions();
    }
    
    /**
     * Inicializa as referências dos elementos da interface
     */
    private void initializeViews(View view) {
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout);
        transactionsList = view.findViewById(R.id.transactions_list);
        addTransactionButton = view.findViewById(R.id.add_transaction_button);
        emptyStateView = view.findViewById(R.id.empty_state_view);
    }
    
    /**
     * Configura o RecyclerView para exibir as transações
     */
    private void setupRecyclerView() {
        transactionsList.setLayoutManager(new LinearLayoutManager(getContext()));
        transactionsAdapter = new TransactionAdapter(transactions, new TransactionAdapter.OnTransactionClickListener() {
            @Override
            public void onTransactionClick(Transaction transaction) {
                openTransactionDetails(transaction);
            }
            
            @Override
            public void onTransactionEdit(Transaction transaction) {
                editTransaction(transaction);
            }
            
            @Override
            public void onTransactionDelete(Transaction transaction) {
                confirmDeleteTransaction(transaction);
            }
        });
        transactionsList.setAdapter(transactionsAdapter);
    }
    
    /**
     * Configura o SwipeRefreshLayout
     */
    private void setupSwipeRefresh() {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadTransactions();
            }
        });
        
        // Define as cores do indicador de refresh
        swipeRefreshLayout.setColorSchemeResources(
                R.color.primary_color,
                R.color.accent_color
        );
    }
    
    /**
     * Configura os listeners de clique
     */
    private void setupClickListeners() {
        addTransactionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddTransaction();
            }
        });
    }
    
    /**
     * Carrega todas as transações do usuário
     */
    private void loadTransactions() {
        // Mostra o indicador de loading se não estiver fazendo refresh
        if (!swipeRefreshLayout.isRefreshing()) {
            showLoading(true);
        }
        
        apiManager.getTransactions(new ApiManager.ApiCallback<List<Transaction>>() {
            @Override
            public void onSuccess(List<Transaction> loadedTransactions) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateTransactionsList(loadedTransactions);
                            showLoading(false);
                            swipeRefreshLayout.setRefreshing(false);
                        }
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showError("Erro ao carregar transações: " + error);
                            showLoading(false);
                            swipeRefreshLayout.setRefreshing(false);
                        }
                    });
                }
            }
        });
    }
    
    /**
     * Atualiza a lista de transações na interface
     */
    private void updateTransactionsList(List<Transaction> newTransactions) {
        transactions.clear();
        transactions.addAll(newTransactions);
        transactionsAdapter.notifyDataSetChanged();
        
        // Mostra/esconde o estado vazio
        if (transactions.isEmpty()) {
            showEmptyState(true);
        } else {
            showEmptyState(false);
        }
    }
    
    /**
     * Abre a tela para adicionar uma nova transação
     */
    private void openAddTransaction() {
        // TODO: Implementar navegação para tela de adicionar transação
        Toast.makeText(getContext(), "Adicionar nova transação", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Abre os detalhes de uma transação
     */
    private void openTransactionDetails(Transaction transaction) {
        // TODO: Implementar navegação para tela de detalhes
        Toast.makeText(getContext(), "Detalhes: " + transaction.getDescription(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Abre a tela de edição de uma transação
     */
    private void editTransaction(Transaction transaction) {
        // TODO: Implementar navegação para tela de edição
        Toast.makeText(getContext(), "Editar: " + transaction.getDescription(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Confirma e exclui uma transação
     */
    private void confirmDeleteTransaction(Transaction transaction) {
        // TODO: Implementar dialog de confirmação
        deleteTransaction(transaction);
    }
    
    /**
     * Exclui uma transação
     */
    private void deleteTransaction(Transaction transaction) {
        apiManager.deleteTransaction(transaction.getId(), new ApiManager.ApiCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Remove da lista local
                            int position = transactions.indexOf(transaction);
                            if (position != -1) {
                                transactions.remove(position);
                                transactionsAdapter.notifyItemRemoved(position);
                            }
                            
                            showSuccess("Transação excluída com sucesso");
                            
                            // Atualiza o estado vazio se necessário
                            if (transactions.isEmpty()) {
                                showEmptyState(true);
                            }
                        }
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showError("Erro ao excluir transação: " + error);
                        }
                    });
                }
            }
        });
    }
    
    /**
     * Mostra/esconde o indicador de loading
     */
    private void showLoading(boolean show) {
        // TODO: Implementar indicador de loading
    }
    
    /**
     * Mostra/esconde o estado vazio
     */
    private void showEmptyState(boolean show) {
        if (show) {
            emptyStateView.setVisibility(View.VISIBLE);
            transactionsList.setVisibility(View.GONE);
        } else {
            emptyStateView.setVisibility(View.GONE);
            transactionsList.setVisibility(View.VISIBLE);
        }
    }
    
    /**
     * Exibe uma mensagem de erro
     */
    private void showError(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }
    
    /**
     * Exibe uma mensagem de sucesso
     */
    private void showSuccess(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Método público para atualizar as transações
     */
    public void refreshTransactions() {
        loadTransactions();
    }
    
    /**
     * Método chamado quando o fragmento fica visível
     */
    @Override
    public void onResume() {
        super.onResume();
        // Atualiza as transações quando o fragmento fica visível
        refreshTransactions();
    }
    
    /**
     * Limpa recursos quando o fragmento é destruído
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (apiManager != null) {
            apiManager.shutdown();
        }
    }
}

