package com.expensetracker;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

/**
 * MainActivity - Atividade principal do aplicativo Android
 * 
 * Esta classe gerencia a navegação entre os diferentes fragmentos do aplicativo
 * (Dashboard, Transações, Categorias e Relatórios) através de uma barra de navegação inferior.
 * 
 * Funcionalidades:
 * - Navegação por abas na parte inferior
 * - Gerenciamento de fragmentos
 * - Controle de estado da navegação
 */
public class MainActivity extends AppCompatActivity {
    
    // Constantes para identificar os fragmentos
    private static final String TAG_DASHBOARD = "dashboard";
    private static final String TAG_TRANSACTIONS = "transactions";
    private static final String TAG_CATEGORIES = "categories";
    private static final String TAG_REPORTS = "reports";
    
    // Elementos da interface de navegação
    private LinearLayout navDashboard, navTransactions, navCategories, navReports;
    private ImageView dashboardIcon, transactionsIcon, categoriesIcon, reportsIcon;
    private TextView dashboardText, transactionsText, categoriesText, reportsText;
    
    // Fragmentos da aplicação
    private DashboardFragment dashboardFragment;
    private TransactionsFragment transactionsFragment;
    private CategoriesFragment categoriesFragment;
    private ReportsFragment reportsFragment;
    
    // Fragmento atualmente ativo
    private String currentFragmentTag = TAG_DASHBOARD;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Inicializa os componentes da interface
        initializeViews();
        
        // Configura os listeners de navegação
        setupNavigationListeners();
        
        // Carrega o fragmento inicial (Dashboard)
        if (savedInstanceState == null) {
            loadFragment(TAG_DASHBOARD);
        } else {
            // Restaura o fragmento ativo após rotação da tela
            currentFragmentTag = savedInstanceState.getString("current_fragment", TAG_DASHBOARD);
            updateNavigationState();
        }
    }
    
    /**
     * Inicializa as referências dos elementos da interface
     */
    private void initializeViews() {
        // Botões de navegação
        navDashboard = findViewById(R.id.nav_dashboard);
        navTransactions = findViewById(R.id.nav_transactions);
        navCategories = findViewById(R.id.nav_categories);
        navReports = findViewById(R.id.nav_reports);
        
        // Ícones de navegação
        dashboardIcon = findViewById(R.id.nav_dashboard_icon);
        transactionsIcon = findViewById(R.id.nav_transactions_icon);
        categoriesIcon = findViewById(R.id.nav_categories_icon);
        reportsIcon = findViewById(R.id.nav_reports_icon);
        
        // Textos de navegação
        dashboardText = findViewById(R.id.nav_dashboard_text);
        transactionsText = findViewById(R.id.nav_transactions_text);
        categoriesText = findViewById(R.id.nav_categories_text);
        reportsText = findViewById(R.id.nav_reports_text);
    }
    
    /**
     * Configura os listeners de clique para os botões de navegação
     */
    private void setupNavigationListeners() {
        navDashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(TAG_DASHBOARD);
            }
        });
        
        navTransactions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(TAG_TRANSACTIONS);
            }
        });
        
        navCategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(TAG_CATEGORIES);
            }
        });
        
        navReports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(TAG_REPORTS);
            }
        });
    }
    
    /**
     * Carrega um fragmento específico baseado na tag fornecida
     * 
     * @param tag Tag do fragmento a ser carregado
     */
    private void loadFragment(String tag) {
        if (tag.equals(currentFragmentTag)) {
            return; // Fragmento já está ativo
        }
        
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        
        // Esconde o fragmento atual se existir
        Fragment currentFragment = fragmentManager.findFragmentByTag(currentFragmentTag);
        if (currentFragment != null) {
            transaction.hide(currentFragment);
        }
        
        // Busca ou cria o fragmento desejado
        Fragment targetFragment = fragmentManager.findFragmentByTag(tag);
        if (targetFragment == null) {
            targetFragment = createFragment(tag);
            transaction.add(R.id.fragment_container, targetFragment, tag);
        } else {
            transaction.show(targetFragment);
        }
        
        // Executa a transação
        transaction.commit();
        
        // Atualiza o estado da navegação
        currentFragmentTag = tag;
        updateNavigationState();
    }
    
    /**
     * Cria uma nova instância do fragmento baseado na tag
     * 
     * @param tag Tag do fragmento a ser criado
     * @return Nova instância do fragmento
     */
    private Fragment createFragment(String tag) {
        switch (tag) {
            case TAG_DASHBOARD:
                if (dashboardFragment == null) {
                    dashboardFragment = new DashboardFragment();
                }
                return dashboardFragment;
                
            case TAG_TRANSACTIONS:
                if (transactionsFragment == null) {
                    transactionsFragment = new TransactionsFragment();
                }
                return transactionsFragment;
                
            case TAG_CATEGORIES:
                if (categoriesFragment == null) {
                    categoriesFragment = new CategoriesFragment();
                }
                return categoriesFragment;
                
            case TAG_REPORTS:
                if (reportsFragment == null) {
                    reportsFragment = new ReportsFragment();
                }
                return reportsFragment;
                
            default:
                return new DashboardFragment();
        }
    }
    
    /**
     * Atualiza o estado visual da navegação para refletir o fragmento ativo
     */
    private void updateNavigationState() {
        // Reset de todos os estados
        resetNavigationState();
        
        // Ativa o estado do fragmento atual
        int selectedColor = getResources().getColor(R.color.nav_selected);
        
        switch (currentFragmentTag) {
            case TAG_DASHBOARD:
                dashboardIcon.setColorFilter(selectedColor);
                dashboardText.setTextColor(selectedColor);
                break;
                
            case TAG_TRANSACTIONS:
                transactionsIcon.setColorFilter(selectedColor);
                transactionsText.setTextColor(selectedColor);
                break;
                
            case TAG_CATEGORIES:
                categoriesIcon.setColorFilter(selectedColor);
                categoriesText.setTextColor(selectedColor);
                break;
                
            case TAG_REPORTS:
                reportsIcon.setColorFilter(selectedColor);
                reportsText.setTextColor(selectedColor);
                break;
        }
    }
    
    /**
     * Reseta o estado visual de todos os botões de navegação
     */
    private void resetNavigationState() {
        int unselectedColor = getResources().getColor(R.color.nav_unselected);
        
        // Reset dos ícones
        dashboardIcon.setColorFilter(unselectedColor);
        transactionsIcon.setColorFilter(unselectedColor);
        categoriesIcon.setColorFilter(unselectedColor);
        reportsIcon.setColorFilter(unselectedColor);
        
        // Reset dos textos
        dashboardText.setTextColor(unselectedColor);
        transactionsText.setTextColor(unselectedColor);
        categoriesText.setTextColor(unselectedColor);
        reportsText.setTextColor(unselectedColor);
    }
    
    /**
     * Salva o estado da atividade para restauração após rotação da tela
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("current_fragment", currentFragmentTag);
    }
    
    /**
     * Método público para permitir que fragmentos naveguem para outros fragmentos
     * 
     * @param tag Tag do fragmento de destino
     */
    public void navigateToFragment(String tag) {
        loadFragment(tag);
    }
    
    /**
     * Retorna a tag do fragmento atualmente ativo
     * 
     * @return Tag do fragmento atual
     */
    public String getCurrentFragmentTag() {
        return currentFragmentTag;
    }
    
    /**
     * Manipula o botão voltar do Android
     * Se não estiver no Dashboard, navega para ele. Caso contrário, sai do app.
     */
    @Override
    public void onBackPressed() {
        if (!currentFragmentTag.equals(TAG_DASHBOARD)) {
            loadFragment(TAG_DASHBOARD);
        } else {
            super.onBackPressed();
        }
    }
}

