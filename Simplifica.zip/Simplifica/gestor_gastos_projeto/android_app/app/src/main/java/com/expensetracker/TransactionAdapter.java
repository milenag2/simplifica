package com.expensetracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * TransactionAdapter - Adaptador para exibir transações em RecyclerView
 * 
 * Esta classe gerencia a exibição de uma lista de transações em um RecyclerView,
 * fornecendo a interface entre os dados e a visualização.
 * 
 * Funcionalidades:
 * - Exibição de transações com formatação apropriada
 * - Diferenciação visual entre receitas e despesas
 * - Callbacks para ações de clique, edição e exclusão
 * - Suporte a transações recorrentes
 */
public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {
    
    private List<Transaction> transactions;
    private OnTransactionClickListener listener;
    
    /**
     * Interface para callbacks de interação com transações
     */
    public interface OnTransactionClickListener {
        void onTransactionClick(Transaction transaction);
        void onTransactionEdit(Transaction transaction);
        void onTransactionDelete(Transaction transaction);
    }
    
    /**
     * Construtor do adaptador
     * 
     * @param transactions Lista de transações
     * @param listener Listener para callbacks
     */
    public TransactionAdapter(List<Transaction> transactions, OnTransactionClickListener listener) {
        this.transactions = transactions;
        this.listener = listener;
    }
    
    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        Transaction transaction = transactions.get(position);
        holder.bind(transaction, listener);
    }
    
    @Override
    public int getItemCount() {
        return transactions.size();
    }
    
    /**
     * Atualiza a lista de transações
     * 
     * @param newTransactions Nova lista de transações
     */
    public void updateTransactions(List<Transaction> newTransactions) {
        this.transactions = newTransactions;
        notifyDataSetChanged();
    }
    
    /**
     * Adiciona uma nova transação à lista
     * 
     * @param transaction Transação a ser adicionada
     */
    public void addTransaction(Transaction transaction) {
        transactions.add(0, transaction); // Adiciona no início da lista
        notifyItemInserted(0);
    }
    
    /**
     * Remove uma transação da lista
     * 
     * @param position Posição da transação a ser removida
     */
    public void removeTransaction(int position) {
        if (position >= 0 && position < transactions.size()) {
            transactions.remove(position);
            notifyItemRemoved(position);
        }
    }
    
    /**
     * Atualiza uma transação específica
     * 
     * @param position Posição da transação
     * @param transaction Dados atualizados da transação
     */
    public void updateTransaction(int position, Transaction transaction) {
        if (position >= 0 && position < transactions.size()) {
            transactions.set(position, transaction);
            notifyItemChanged(position);
        }
    }
    
    /**
     * ViewHolder para itens de transação
     */
    public static class TransactionViewHolder extends RecyclerView.ViewHolder {
        
        private ImageView typeIcon;
        private TextView descriptionText;
        private TextView amountText;
        private TextView dateText;
        private TextView categoryText;
        private ImageView recurringIcon;
        private ImageView editButton;
        private ImageView deleteButton;
        
        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            
            // Inicializa as views
            typeIcon = itemView.findViewById(R.id.transaction_type_icon);
            descriptionText = itemView.findViewById(R.id.transaction_description);
            amountText = itemView.findViewById(R.id.transaction_amount);
            dateText = itemView.findViewById(R.id.transaction_date);
            categoryText = itemView.findViewById(R.id.transaction_category);
            recurringIcon = itemView.findViewById(R.id.transaction_recurring_icon);
            editButton = itemView.findViewById(R.id.transaction_edit_button);
            deleteButton = itemView.findViewById(R.id.transaction_delete_button);
        }
        
        /**
         * Vincula os dados da transação às views
         * 
         * @param transaction Dados da transação
         * @param listener Listener para callbacks
         */
        public void bind(Transaction transaction, OnTransactionClickListener listener) {
            // Define a descrição
            descriptionText.setText(transaction.getDescription());
            
            // Define o valor formatado
            amountText.setText(transaction.getFormattedAmount());
            
            // Define a data formatada
            dateText.setText(transaction.getFormattedDate());
            
            // Define a categoria
            if (transaction.getCategoryName() != null && !transaction.getCategoryName().isEmpty()) {
                categoryText.setText(transaction.getCategoryName());
                categoryText.setVisibility(View.VISIBLE);
            } else {
                categoryText.setVisibility(View.GONE);
            }
            
            // Configura o ícone e cor baseado no tipo
            if (transaction.isIncome()) {
                typeIcon.setImageResource(R.drawable.ic_arrow_up);
                typeIcon.setColorFilter(itemView.getContext().getResources().getColor(R.color.income_color));
                amountText.setTextColor(itemView.getContext().getResources().getColor(R.color.income_color));
            } else {
                typeIcon.setImageResource(R.drawable.ic_arrow_down);
                typeIcon.setColorFilter(itemView.getContext().getResources().getColor(R.color.expense_color));
                amountText.setTextColor(itemView.getContext().getResources().getColor(R.color.expense_color));
            }
            
            // Mostra/esconde ícone de recorrência
            if (transaction.isRecurring()) {
                recurringIcon.setVisibility(View.VISIBLE);
                recurringIcon.setImageResource(R.drawable.ic_recurring);
            } else {
                recurringIcon.setVisibility(View.GONE);
            }
            
            // Configura listeners
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onTransactionClick(transaction);
                    }
                }
            });
            
            editButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onTransactionEdit(transaction);
                    }
                }
            });
            
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onTransactionDelete(transaction);
                    }
                }
            });
        }
    }
}

