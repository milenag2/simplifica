package com.expensetracker;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Transaction - Modelo de dados para representar uma transação financeira
 * 
 * Esta classe encapsula todos os dados relacionados a uma transação,
 * incluindo receitas e despesas, com suporte a transações recorrentes.
 * 
 * Atributos:
 * - ID único da transação
 * - ID do usuário proprietário
 * - ID da categoria associada
 * - Descrição da transação
 * - Valor (positivo para receitas, negativo para despesas)
 * - Tipo (income/expense)
 * - Data da transação
 * - Configurações de recorrência
 * - Nome da categoria (para exibição)
 */
public class Transaction {
    
    // Constantes para tipos de transação
    public static final String TYPE_INCOME = "income";
    public static final String TYPE_EXPENSE = "expense";
    
    // Constantes para frequências de recorrência
    public static final String FREQUENCY_DAILY = "daily";
    public static final String FREQUENCY_WEEKLY = "weekly";
    public static final String FREQUENCY_MONTHLY = "monthly";
    public static final String FREQUENCY_YEARLY = "yearly";
    
    // Formato de data usado pela API
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    
    // Atributos da transação
    private int id;
    private int userId;
    private int categoryId;
    private String description;
    private double amount;
    private String type;
    private String date;
    private boolean isRecurring;
    private String recurringFrequency;
    private String recurringEndDate;
    private String categoryName; // Campo adicional para exibição
    
    /**
     * Construtor padrão
     */
    public Transaction() {
        this.isRecurring = false;
    }
    
    /**
     * Construtor com parâmetros principais
     * 
     * @param description Descrição da transação
     * @param amount Valor da transação
     * @param type Tipo da transação (income/expense)
     * @param categoryId ID da categoria
     * @param date Data da transação
     */
    public Transaction(String description, double amount, String type, int categoryId, String date) {
        this();
        this.description = description;
        this.amount = amount;
        this.type = type;
        this.categoryId = categoryId;
        this.date = date;
    }
    
    // Getters e Setters
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public int getCategoryId() {
        return categoryId;
    }
    
    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public void setAmount(double amount) {
        this.amount = amount;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getDate() {
        return date;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
    public boolean isRecurring() {
        return isRecurring;
    }
    
    public void setRecurring(boolean recurring) {
        isRecurring = recurring;
    }
    
    public String getRecurringFrequency() {
        return recurringFrequency;
    }
    
    public void setRecurringFrequency(String recurringFrequency) {
        this.recurringFrequency = recurringFrequency;
    }
    
    public String getRecurringEndDate() {
        return recurringEndDate;
    }
    
    public void setRecurringEndDate(String recurringEndDate) {
        this.recurringEndDate = recurringEndDate;
    }
    
    public String getCategoryName() {
        return categoryName;
    }
    
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    
    // Métodos auxiliares
    
    /**
     * Verifica se a transação é uma receita
     * 
     * @return true se for receita, false caso contrário
     */
    public boolean isIncome() {
        return TYPE_INCOME.equals(type);
    }
    
    /**
     * Verifica se a transação é uma despesa
     * 
     * @return true se for despesa, false caso contrário
     */
    public boolean isExpense() {
        return TYPE_EXPENSE.equals(type);
    }
    
    /**
     * Retorna o valor absoluto da transação
     * 
     * @return Valor absoluto
     */
    public double getAbsoluteAmount() {
        return Math.abs(amount);
    }
    
    /**
     * Retorna o valor formatado como moeda brasileira
     * 
     * @return Valor formatado (ex: "R$ 123,45")
     */
    public String getFormattedAmount() {
        return String.format(Locale.getDefault(), "R$ %.2f", getAbsoluteAmount());
    }
    
    /**
     * Converte a string de data em um objeto Date
     * 
     * @return Objeto Date ou null se a data for inválida
     */
    public Date getDateAsDate() {
        if (date == null || date.isEmpty()) {
            return null;
        }
        
        try {
            return DATE_FORMAT.parse(date);
        } catch (ParseException e) {
            return null;
        }
    }
    
    /**
     * Define a data da transação a partir de um objeto Date
     * 
     * @param date Objeto Date
     */
    public void setDateFromDate(Date date) {
        if (date != null) {
            this.date = DATE_FORMAT.format(date);
        } else {
            this.date = null;
        }
    }
    
    /**
     * Retorna a data formatada para exibição (dd/MM/yyyy)
     * 
     * @return Data formatada ou string vazia se inválida
     */
    public String getFormattedDate() {
        Date dateObj = getDateAsDate();
        if (dateObj != null) {
            SimpleDateFormat displayFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            return displayFormat.format(dateObj);
        }
        return "";
    }
    
    /**
     * Retorna a descrição da frequência de recorrência em português
     * 
     * @return Descrição da frequência ou string vazia se não recorrente
     */
    public String getRecurringFrequencyDescription() {
        if (!isRecurring || recurringFrequency == null) {
            return "";
        }
        
        switch (recurringFrequency) {
            case FREQUENCY_DAILY:
                return "Diário";
            case FREQUENCY_WEEKLY:
                return "Semanal";
            case FREQUENCY_MONTHLY:
                return "Mensal";
            case FREQUENCY_YEARLY:
                return "Anual";
            default:
                return recurringFrequency;
        }
    }
    
    /**
     * Retorna a data de término da recorrência formatada
     * 
     * @return Data formatada ou string vazia se não definida
     */
    public String getFormattedRecurringEndDate() {
        if (recurringEndDate == null || recurringEndDate.isEmpty()) {
            return "";
        }
        
        try {
            Date endDate = DATE_FORMAT.parse(recurringEndDate);
            SimpleDateFormat displayFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            return displayFormat.format(endDate);
        } catch (ParseException e) {
            return recurringEndDate;
        }
    }
    
    /**
     * Valida se os dados da transação estão corretos
     * 
     * @return true se válida, false caso contrário
     */
    public boolean isValid() {
        // Verifica campos obrigatórios
        if (description == null || description.trim().isEmpty()) {
            return false;
        }
        
        if (amount == 0) {
            return false;
        }
        
        if (type == null || (!TYPE_INCOME.equals(type) && !TYPE_EXPENSE.equals(type))) {
            return false;
        }
        
        if (categoryId <= 0) {
            return false;
        }
        
        if (date == null || date.isEmpty()) {
            return false;
        }
        
        // Verifica se a data é válida
        if (getDateAsDate() == null) {
            return false;
        }
        
        // Se for recorrente, verifica campos de recorrência
        if (isRecurring) {
            if (recurringFrequency == null || recurringFrequency.isEmpty()) {
                return false;
            }
            
            // Verifica se a frequência é válida
            if (!FREQUENCY_DAILY.equals(recurringFrequency) &&
                !FREQUENCY_WEEKLY.equals(recurringFrequency) &&
                !FREQUENCY_MONTHLY.equals(recurringFrequency) &&
                !FREQUENCY_YEARLY.equals(recurringFrequency)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Cria uma cópia da transação
     * 
     * @return Nova instância com os mesmos dados
     */
    public Transaction copy() {
        Transaction copy = new Transaction();
        copy.id = this.id;
        copy.userId = this.userId;
        copy.categoryId = this.categoryId;
        copy.description = this.description;
        copy.amount = this.amount;
        copy.type = this.type;
        copy.date = this.date;
        copy.isRecurring = this.isRecurring;
        copy.recurringFrequency = this.recurringFrequency;
        copy.recurringEndDate = this.recurringEndDate;
        copy.categoryName = this.categoryName;
        
        return copy;
    }
    
    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", description='" + description + '\'' +
                ", amount=" + amount +
                ", type='" + type + '\'' +
                ", date='" + date + '\'' +
                ", categoryName='" + categoryName + '\'' +
                ", isRecurring=" + isRecurring +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Transaction that = (Transaction) obj;
        return id == that.id;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}

