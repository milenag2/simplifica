# Rotas para gerenciar categorias
from flask import Blueprint, request, jsonify
from src.models.user import db
from src.models.category import Category

# Criando o blueprint para as rotas de categoria
category_bp = Blueprint('category', __name__)

@category_bp.route('/categories', methods=['GET'])
def get_categories():
    """
    Endpoint para obter todas as categorias de um usuário.
    
    Query Parameters:
        user_id: ID do usuário (obrigatório)
    
    Returns:
        JSON: Lista de categorias do usuário
    """
    try:
        # Obtém o user_id dos parâmetros da query
        user_id = request.args.get('user_id')
        
        if not user_id:
            return jsonify({'error': 'user_id é obrigatório'}), 400
        
        # Busca todas as categorias do usuário
        categories = Category.query.filter_by(user_id=user_id).all()
        
        # Converte as categorias para dicionários
        categories_list = [category.to_dict() for category in categories]
        
        return jsonify({
            'success': True,
            'categories': categories_list
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@category_bp.route('/categories', methods=['POST'])
def create_category():
    """
    Endpoint para criar uma nova categoria.
    
    Body (JSON):
        user_id: ID do usuário
        name: Nome da categoria
        type: Tipo da categoria ('expense' ou 'income')
    
    Returns:
        JSON: Dados da categoria criada
    """
    try:
        # Obtém os dados do corpo da requisição
        data = request.get_json()
        
        # Validação dos campos obrigatórios
        if not data or not all(key in data for key in ['user_id', 'name', 'type']):
            return jsonify({'error': 'user_id, name e type são obrigatórios'}), 400
        
        # Validação do tipo
        if data['type'] not in ['expense', 'income']:
            return jsonify({'error': 'type deve ser "expense" ou "income"'}), 400
        
        # Verifica se já existe uma categoria com o mesmo nome para o usuário
        existing_category = Category.query.filter_by(
            user_id=data['user_id'], 
            name=data['name']
        ).first()
        
        if existing_category:
            return jsonify({'error': 'Categoria com este nome já existe'}), 400
        
        # Cria a nova categoria
        new_category = Category(
            user_id=data['user_id'],
            name=data['name'],
            type=data['type']
        )
        
        # Salva no banco de dados
        db.session.add(new_category)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'category': new_category.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@category_bp.route('/categories/<int:category_id>', methods=['PUT'])
def update_category(category_id):
    """
    Endpoint para atualizar uma categoria existente.
    
    Path Parameters:
        category_id: ID da categoria a ser atualizada
    
    Body (JSON):
        name: Novo nome da categoria (opcional)
        type: Novo tipo da categoria (opcional)
    
    Returns:
        JSON: Dados da categoria atualizada
    """
    try:
        # Busca a categoria pelo ID
        category = Category.query.get(category_id)
        
        if not category:
            return jsonify({'error': 'Categoria não encontrada'}), 404
        
        # Obtém os dados do corpo da requisição
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        # Atualiza os campos se fornecidos
        if 'name' in data:
            category.name = data['name']
        
        if 'type' in data:
            if data['type'] not in ['expense', 'income']:
                return jsonify({'error': 'type deve ser "expense" ou "income"'}), 400
            category.type = data['type']
        
        # Salva as alterações
        db.session.commit()
        
        return jsonify({
            'success': True,
            'category': category.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@category_bp.route('/categories/<int:category_id>', methods=['DELETE'])
def delete_category(category_id):
    """
    Endpoint para deletar uma categoria.
    
    Path Parameters:
        category_id: ID da categoria a ser deletada
    
    Returns:
        JSON: Confirmação da exclusão
    """
    try:
        # Busca a categoria pelo ID
        category = Category.query.get(category_id)
        
        if not category:
            return jsonify({'error': 'Categoria não encontrada'}), 404
        
        # Remove a categoria
        db.session.delete(category)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Categoria deletada com sucesso'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

