# Rotas para gerenciar transações
from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from src.models.user import db
from src.models.transaction import Transaction
from src.models.category import Category

# Criando o blueprint para as rotas de transação
transaction_bp = Blueprint('transaction', __name__)

@transaction_bp.route('/transactions', methods=['GET'])
def get_transactions():
    """
    Endpoint para obter todas as transações de um usuário.
    
    Query Parameters:
        user_id: ID do usuário (obrigatório)
        start_date: Data de início (opcional, formato: YYYY-MM-DD)
        end_date: Data de fim (opcional, formato: YYYY-MM-DD)
        type: Tipo de transação (opcional, 'expense' ou 'income')
        category_id: ID da categoria (opcional)
    
    Returns:
        JSON: Lista de transações do usuário
    """
    try:
        # Obtém os parâmetros da query
        user_id = request.args.get('user_id')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        transaction_type = request.args.get('type')
        category_id = request.args.get('category_id')
        
        if not user_id:
            return jsonify({'error': 'user_id é obrigatório'}), 400
        
        # Inicia a query base
        query = Transaction.query.filter_by(user_id=user_id)
        
        # Aplica filtros opcionais
        if start_date:
            start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
            query = query.filter(Transaction.date >= start_date_obj)
        
        if end_date:
            end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
            query = query.filter(Transaction.date <= end_date_obj)
        
        if transaction_type:
            query = query.filter_by(type=transaction_type)
        
        if category_id:
            query = query.filter_by(category_id=category_id)
        
        # Ordena por data (mais recente primeiro)
        transactions = query.order_by(Transaction.date.desc()).all()
        
        # Converte as transações para dicionários
        transactions_list = [transaction.to_dict() for transaction in transactions]
        
        return jsonify({
            'success': True,
            'transactions': transactions_list
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions', methods=['POST'])
def create_transaction():
    """
    Endpoint para criar uma nova transação.
    
    Body (JSON):
        user_id: ID do usuário
        category_id: ID da categoria
        description: Descrição da transação
        amount: Valor da transação
        type: Tipo da transação ('expense' ou 'income')
        date: Data da transação (opcional, formato: YYYY-MM-DD)
        is_recurring: Se é recorrente (opcional, default: false)
        recurring_frequency: Frequência da recorrência (opcional)
        recurring_end_date: Data de fim da recorrência (opcional)
    
    Returns:
        JSON: Dados da transação criada
    """
    try:
        # Obtém os dados do corpo da requisição
        data = request.get_json()
        
        # Validação dos campos obrigatórios
        required_fields = ['user_id', 'category_id', 'description', 'amount', 'type']
        if not data or not all(key in data for key in required_fields):
            return jsonify({'error': 'user_id, category_id, description, amount e type são obrigatórios'}), 400
        
        # Validação do tipo
        if data['type'] not in ['expense', 'income']:
            return jsonify({'error': 'type deve ser "expense" ou "income"'}), 400
        
        # Verifica se a categoria existe
        category = Category.query.get(data['category_id'])
        if not category:
            return jsonify({'error': 'Categoria não encontrada'}), 404
        
        # Processa a data
        transaction_date = datetime.utcnow()
        if 'date' in data and data['date']:
            transaction_date = datetime.strptime(data['date'], '%Y-%m-%d')
        
        # Processa a data de fim da recorrência
        recurring_end_date = None
        if 'recurring_end_date' in data and data['recurring_end_date']:
            recurring_end_date = datetime.strptime(data['recurring_end_date'], '%Y-%m-%d')
        
        # Cria a nova transação
        new_transaction = Transaction(
            user_id=data['user_id'],
            category_id=data['category_id'],
            description=data['description'],
            amount=data['amount'],
            type=data['type'],
            date=transaction_date,
            is_recurring=data.get('is_recurring', False),
            recurring_frequency=data.get('recurring_frequency'),
            recurring_end_date=recurring_end_date
        )
        
        # Salva no banco de dados
        db.session.add(new_transaction)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'transaction': new_transaction.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['GET'])
def get_transaction(transaction_id):
    """
    Endpoint para obter uma transação específica.
    
    Path Parameters:
        transaction_id: ID da transação
    
    Returns:
        JSON: Dados da transação
    """
    try:
        # Busca a transação pelo ID
        transaction = Transaction.query.get(transaction_id)
        
        if not transaction:
            return jsonify({'error': 'Transação não encontrada'}), 404
        
        return jsonify({
            'success': True,
            'transaction': transaction.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['PUT'])
def update_transaction(transaction_id):
    """
    Endpoint para atualizar uma transação existente.
    
    Path Parameters:
        transaction_id: ID da transação a ser atualizada
    
    Body (JSON): Campos a serem atualizados
    
    Returns:
        JSON: Dados da transação atualizada
    """
    try:
        # Busca a transação pelo ID
        transaction = Transaction.query.get(transaction_id)
        
        if not transaction:
            return jsonify({'error': 'Transação não encontrada'}), 404
        
        # Obtém os dados do corpo da requisição
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        # Atualiza os campos se fornecidos
        if 'category_id' in data:
            category = Category.query.get(data['category_id'])
            if not category:
                return jsonify({'error': 'Categoria não encontrada'}), 404
            transaction.category_id = data['category_id']
        
        if 'description' in data:
            transaction.description = data['description']
        
        if 'amount' in data:
            transaction.amount = data['amount']
        
        if 'type' in data:
            if data['type'] not in ['expense', 'income']:
                return jsonify({'error': 'type deve ser "expense" ou "income"'}), 400
            transaction.type = data['type']
        
        if 'date' in data:
            transaction.date = datetime.strptime(data['date'], '%Y-%m-%d')
        
        if 'is_recurring' in data:
            transaction.is_recurring = data['is_recurring']
        
        if 'recurring_frequency' in data:
            transaction.recurring_frequency = data['recurring_frequency']
        
        if 'recurring_end_date' in data:
            if data['recurring_end_date']:
                transaction.recurring_end_date = datetime.strptime(data['recurring_end_date'], '%Y-%m-%d')
            else:
                transaction.recurring_end_date = None
        
        # Salva as alterações
        db.session.commit()
        
        return jsonify({
            'success': True,
            'transaction': transaction.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['DELETE'])
def delete_transaction(transaction_id):
    """
    Endpoint para deletar uma transação.
    
    Path Parameters:
        transaction_id: ID da transação a ser deletada
    
    Returns:
        JSON: Confirmação da exclusão
    """
    try:
        # Busca a transação pelo ID
        transaction = Transaction.query.get(transaction_id)
        
        if not transaction:
            return jsonify({'error': 'Transação não encontrada'}), 404
        
        # Remove a transação
        db.session.delete(transaction)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Transação deletada com sucesso'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

