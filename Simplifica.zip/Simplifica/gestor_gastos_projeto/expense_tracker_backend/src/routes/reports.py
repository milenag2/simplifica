# Rotas para relatórios e cálculos financeiros
from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from sqlalchemy import func, extract
from src.models.user import db
from src.models.transaction import Transaction
from src.models.category import Category

# Criando o blueprint para as rotas de relatórios
reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/balance/monthly', methods=['GET'])
def get_monthly_balance():
    """
    Endpoint para calcular o saldo mensal de um usuário.
    
    Query Parameters:
        user_id: ID do usuário (obrigatório)
        year: Ano (opcional, default: ano atual)
        month: Mês (opcional, default: mês atual)
    
    Returns:
        JSON: Saldo mensal (receitas - despesas)
    """
    try:
        # Obtém os parâmetros da query
        user_id = request.args.get('user_id')
        year = request.args.get('year', datetime.now().year)
        month = request.args.get('month', datetime.now().month)
        
        if not user_id:
            return jsonify({'error': 'user_id é obrigatório'}), 400
        
        # Converte para inteiros
        year = int(year)
        month = int(month)
        
        # Calcula o total de receitas do mês
        income_total = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user_id,
            Transaction.type == 'income',
            extract('year', Transaction.date) == year,
            extract('month', Transaction.date) == month
        ).scalar() or 0
        
        # Calcula o total de despesas do mês
        expense_total = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user_id,
            Transaction.type == 'expense',
            extract('year', Transaction.date) == year,
            extract('month', Transaction.date) == month
        ).scalar() or 0
        
        # Calcula o saldo (receitas - despesas)
        balance = income_total - expense_total
        
        return jsonify({
            'success': True,
            'year': year,
            'month': month,
            'income_total': income_total,
            'expense_total': expense_total,
            'balance': balance
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@reports_bp.route('/reports/daily', methods=['GET'])
def get_daily_report():
    """
    Endpoint para obter relatório diário de transações.
    
    Query Parameters:
        user_id: ID do usuário (obrigatório)
        date: Data específica (opcional, formato: YYYY-MM-DD, default: hoje)
    
    Returns:
        JSON: Relatório diário com transações e totais
    """
    try:
        # Obtém os parâmetros da query
        user_id = request.args.get('user_id')
        date_str = request.args.get('date')
        
        if not user_id:
            return jsonify({'error': 'user_id é obrigatório'}), 400
        
        # Define a data (hoje se não especificada)
        if date_str:
            target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        else:
            target_date = datetime.now().date()
        
        # Busca todas as transações do dia
        transactions = Transaction.query.filter(
            Transaction.user_id == user_id,
            func.date(Transaction.date) == target_date
        ).order_by(Transaction.date.desc()).all()
        
        # Calcula totais
        income_total = sum(t.amount for t in transactions if t.type == 'income')
        expense_total = sum(t.amount for t in transactions if t.type == 'expense')
        
        return jsonify({
            'success': True,
            'date': target_date.isoformat(),
            'transactions': [t.to_dict() for t in transactions],
            'income_total': income_total,
            'expense_total': expense_total,
            'balance': income_total - expense_total,
            'transaction_count': len(transactions)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@reports_bp.route('/reports/monthly', methods=['GET'])
def get_monthly_report():
    """
    Endpoint para obter relatório mensal de transações.
    
    Query Parameters:
        user_id: ID do usuário (obrigatório)
        year: Ano (opcional, default: ano atual)
        month: Mês (opcional, default: mês atual)
    
    Returns:
        JSON: Relatório mensal com transações e totais
    """
    try:
        # Obtém os parâmetros da query
        user_id = request.args.get('user_id')
        year = request.args.get('year', datetime.now().year)
        month = request.args.get('month', datetime.now().month)
        
        if not user_id:
            return jsonify({'error': 'user_id é obrigatório'}), 400
        
        # Converte para inteiros
        year = int(year)
        month = int(month)
        
        # Busca todas as transações do mês
        transactions = Transaction.query.filter(
            Transaction.user_id == user_id,
            extract('year', Transaction.date) == year,
            extract('month', Transaction.date) == month
        ).order_by(Transaction.date.desc()).all()
        
        # Calcula totais
        income_total = sum(t.amount for t in transactions if t.type == 'income')
        expense_total = sum(t.amount for t in transactions if t.type == 'expense')
        
        return jsonify({
            'success': True,
            'year': year,
            'month': month,
            'transactions': [t.to_dict() for t in transactions],
            'income_total': income_total,
            'expense_total': expense_total,
            'balance': income_total - expense_total,
            'transaction_count': len(transactions)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@reports_bp.route('/reports/annual', methods=['GET'])
def get_annual_report():
    """
    Endpoint para obter relatório anual de transações.
    
    Query Parameters:
        user_id: ID do usuário (obrigatório)
        year: Ano (opcional, default: ano atual)
    
    Returns:
        JSON: Relatório anual com transações e totais por mês
    """
    try:
        # Obtém os parâmetros da query
        user_id = request.args.get('user_id')
        year = request.args.get('year', datetime.now().year)
        
        if not user_id:
            return jsonify({'error': 'user_id é obrigatório'}), 400
        
        # Converte para inteiro
        year = int(year)
        
        # Busca todas as transações do ano
        transactions = Transaction.query.filter(
            Transaction.user_id == user_id,
            extract('year', Transaction.date) == year
        ).order_by(Transaction.date.desc()).all()
        
        # Agrupa por mês
        monthly_data = {}
        for month in range(1, 13):
            monthly_transactions = [t for t in transactions if t.date.month == month]
            income_total = sum(t.amount for t in monthly_transactions if t.type == 'income')
            expense_total = sum(t.amount for t in monthly_transactions if t.type == 'expense')
            
            monthly_data[month] = {
                'month': month,
                'income_total': income_total,
                'expense_total': expense_total,
                'balance': income_total - expense_total,
                'transaction_count': len(monthly_transactions)
            }
        
        # Calcula totais anuais
        annual_income = sum(t.amount for t in transactions if t.type == 'income')
        annual_expense = sum(t.amount for t in transactions if t.type == 'expense')
        
        return jsonify({
            'success': True,
            'year': year,
            'monthly_data': monthly_data,
            'annual_income': annual_income,
            'annual_expense': annual_expense,
            'annual_balance': annual_income - annual_expense,
            'total_transactions': len(transactions)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@reports_bp.route('/reports/categories', methods=['GET'])
def get_category_report():
    """
    Endpoint para obter relatório de transações por categoria.
    
    Query Parameters:
        user_id: ID do usuário (obrigatório)
        start_date: Data de início (opcional, formato: YYYY-MM-DD)
        end_date: Data de fim (opcional, formato: YYYY-MM-DD)
        type: Tipo de transação (opcional, 'expense' ou 'income')
    
    Returns:
        JSON: Relatório por categoria com totais
    """
    try:
        # Obtém os parâmetros da query
        user_id = request.args.get('user_id')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        transaction_type = request.args.get('type')
        
        if not user_id:
            return jsonify({'error': 'user_id é obrigatório'}), 400
        
        # Inicia a query base
        query = db.session.query(
            Category.id,
            Category.name,
            Category.type,
            func.sum(Transaction.amount).label('total'),
            func.count(Transaction.id).label('count')
        ).join(Transaction).filter(Transaction.user_id == user_id)
        
        # Aplica filtros opcionais
        if start_date:
            start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
            query = query.filter(Transaction.date >= start_date_obj)
        
        if end_date:
            end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
            query = query.filter(Transaction.date <= end_date_obj)
        
        if transaction_type:
            query = query.filter(Transaction.type == transaction_type)
        
        # Agrupa por categoria
        results = query.group_by(Category.id, Category.name, Category.type).all()
        
        # Formata os resultados
        category_data = []
        for result in results:
            category_data.append({
                'category_id': result.id,
                'category_name': result.name,
                'category_type': result.type,
                'total_amount': float(result.total),
                'transaction_count': result.count
            })
        
        return jsonify({
            'success': True,
            'category_data': category_data,
            'filters': {
                'start_date': start_date,
                'end_date': end_date,
                'type': transaction_type
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

