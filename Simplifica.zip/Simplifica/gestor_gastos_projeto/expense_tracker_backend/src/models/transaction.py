# Modelo para transações (gastos e receitas)
from datetime import datetime
from src.models.user import db

class Transaction(db.Model):
    """
    Modelo para representar transações financeiras (gastos e receitas).
    
    Atributos:
        id: Identificador único da transação
        user_id: Referência ao usuário que registrou a transação
        category_id: Referência à categoria da transação
        description: Descrição da transação
        amount: Valor da transação (positivo para receita, negativo para despesa)
        type: Tipo da transação ('expense' para despesa, 'income' para receita)
        date: Data da transação
        is_recurring: Indica se é uma transação recorrente
        recurring_frequency: Frequência da recorrência (daily, weekly, monthly, yearly)
        recurring_end_date: Data de término da recorrência
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    description = db.Column(db.String(200), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(20), nullable=False)  # 'expense' ou 'income'
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    is_recurring = db.Column(db.Boolean, default=False)
    recurring_frequency = db.Column(db.String(20))  # 'daily', 'weekly', 'monthly', 'yearly'
    recurring_end_date = db.Column(db.DateTime)
    
    # Relacionamentos
    user = db.relationship('User', backref=db.backref('transactions', lazy=True))
    category = db.relationship('Category', backref=db.backref('transactions', lazy=True))

    def __repr__(self):
        return f'<Transaction {self.description}: {self.amount} ({self.type})>'

    def to_dict(self):
        """
        Converte o objeto Transaction para um dicionário para serialização JSON.
        
        Returns:
            dict: Dicionário com os dados da transação
        """
        return {
            'id': self.id,
            'user_id': self.user_id,
            'category_id': self.category_id,
            'description': self.description,
            'amount': self.amount,
            'type': self.type,
            'date': self.date.isoformat() if self.date else None,
            'is_recurring': self.is_recurring,
            'recurring_frequency': self.recurring_frequency,
            'recurring_end_date': self.recurring_end_date.isoformat() if self.recurring_end_date else None,
            'category_name': self.category.name if self.category else None
        }

