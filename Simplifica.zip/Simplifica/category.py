# Modelo para categorias de gastos e receitas
from src.models.user import db

class Category(db.Model):
    """
    Modelo para representar categorias de transações (gastos e receitas).
    
    Atributos:
        id: Identificador único da categoria
        user_id: Referência ao usuário proprietário da categoria
        name: Nome da categoria (ex: Alimentação, Transporte, Salário)
        type: Tipo da categoria ('expense' para despesa, 'income' para receita)
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(20), nullable=False)  # 'expense' ou 'income'
    
    # Relacionamento com o usuário
    user = db.relationship('User', backref=db.backref('categories', lazy=True))

    def __repr__(self):
        return f'<Category {self.name} ({self.type})>'

    def to_dict(self):
        """
        Converte o objeto Category para um dicionário para serialização JSON.
        
        Returns:
            dict: Dicionário com os dados da categoria
        """
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'type': self.type
        }

