package com.expensetracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * CategoryAdapter - Adaptador para exibir categorias em RecyclerView
 * 
 * Este adaptador gerencia a exibição de categorias em um grid layout,
 * mostrando informações como nome, tipo e permitindo ações de edição/exclusão.
 * 
 * Funcionalidades:
 * - Exibição de categorias em cards
 * - Diferenciação visual entre receitas e despesas
 * - Callbacks para ações de clique, edição e exclusão
 * - Suporte a estados vazios
 */
public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder> {
    
    // Lista de categorias
    private List<Category> categories;
    
    // Contexto da aplicação
    private Context context;
    
    // Interface para callbacks de clique
    private OnCategoryClickListener clickListener;
    
    /**
     * Interface para callbacks de ações nas categorias
     */
    public interface OnCategoryClickListener {
        void onCategoryClick(Category category);
        void onCategoryEdit(Category category);
        void onCategoryDelete(Category category);
    }
    
    /**
     * Construtor do adaptador
     * 
     * @param categories Lista de categorias
     * @param clickListener Listener para ações de clique
     */
    public CategoryAdapter(List<Category> categories, OnCategoryClickListener clickListener) {
        this.categories = categories;
        this.clickListener = clickListener;
    }
    
    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        return new CategoryViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        Category category = categories.get(position);
        holder.bind(category);
    }
    
    @Override
    public int getItemCount() {
        return categories != null ? categories.size() : 0;
    }
    
    /**
     * Atualiza a lista de categorias
     * 
     * @param newCategories Nova lista de categorias
     */
    public void updateCategories(List<Category> newCategories) {
        this.categories = newCategories;
        notifyDataSetChanged();
    }
    
    /**
     * Adiciona uma nova categoria à lista
     * 
     * @param category Categoria a ser adicionada
     */
    public void addCategory(Category category) {
        if (categories != null) {
            categories.add(category);
            notifyItemInserted(categories.size() - 1);
        }
    }
    
    /**
     * Remove uma categoria da lista
     * 
     * @param position Posição da categoria a ser removida
     */
    public void removeCategory(int position) {
        if (categories != null && position >= 0 && position < categories.size()) {
            categories.remove(position);
            notifyItemRemoved(position);
        }
    }
    
    /**
     * Atualiza uma categoria específica
     * 
     * @param position Posição da categoria
     * @param category Categoria atualizada
     */
    public void updateCategory(int position, Category category) {
        if (categories != null && position >= 0 && position < categories.size()) {
            categories.set(position, category);
            notifyItemChanged(position);
        }
    }
    
    /**
     * ViewHolder para itens de categoria
     */
    public class CategoryViewHolder extends RecyclerView.ViewHolder {
        
        // Elementos da interface
        private TextView categoryName;
        private TextView categoryType;
        private ImageView categoryIcon;
        private ImageView editButton;
        private ImageView deleteButton;
        private View categoryCard;
        
        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            
            // Inicializa as referências dos elementos
            categoryName = itemView.findViewById(R.id.category_name);
            categoryType = itemView.findViewById(R.id.category_type);
            categoryIcon = itemView.findViewById(R.id.category_icon);
            editButton = itemView.findViewById(R.id.edit_button);
            deleteButton = itemView.findViewById(R.id.delete_button);
            categoryCard = itemView.findViewById(R.id.category_card);
        }
        
        /**
         * Vincula os dados da categoria aos elementos da interface
         * 
         * @param category Categoria a ser exibida
         */
        public void bind(Category category) {
            // Define o nome da categoria
            categoryName.setText(category.getName());
            
            // Define o tipo da categoria
            String typeText = category.getType().equals("income") ? "Receita" : "Despesa";
            categoryType.setText(typeText);
            
            // Define o ícone baseado no tipo
            if (category.getType().equals("income")) {
                categoryIcon.setImageResource(R.drawable.ic_arrow_up);
                categoryCard.setBackgroundResource(R.drawable.card_income_background);
            } else {
                categoryIcon.setImageResource(R.drawable.ic_arrow_down);
                categoryCard.setBackgroundResource(R.drawable.card_expense_background);
            }
            
            // Configura listeners de clique
            setupClickListeners(category);
        }
        
        /**
         * Configura os listeners de clique para os elementos
         * 
         * @param category Categoria associada ao item
         */
        private void setupClickListeners(Category category) {
            // Clique no card da categoria
            categoryCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (clickListener != null) {
                        clickListener.onCategoryClick(category);
                    }
                }
            });
            
            // Clique no botão de editar
            editButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (clickListener != null) {
                        clickListener.onCategoryEdit(category);
                    }
                }
            });
            
            // Clique no botão de excluir
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (clickListener != null) {
                        clickListener.onCategoryDelete(category);
                    }
                }
            });
        }
    }
    
    /**
     * Obtém uma categoria pela posição
     * 
     * @param position Posição da categoria
     * @return Categoria na posição especificada
     */
    public Category getCategoryAt(int position) {
        if (categories != null && position >= 0 && position < categories.size()) {
            return categories.get(position);
        }
        return null;
    }
    
    /**
     * Encontra a posição de uma categoria pelo ID
     * 
     * @param categoryId ID da categoria
     * @return Posição da categoria ou -1 se não encontrada
     */
    public int findCategoryPosition(int categoryId) {
        if (categories != null) {
            for (int i = 0; i < categories.size(); i++) {
                if (categories.get(i).getId() == categoryId) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    /**
     * Verifica se a lista está vazia
     * 
     * @return true se a lista estiver vazia
     */
    public boolean isEmpty() {
        return categories == null || categories.isEmpty();
    }
    
    /**
     * Limpa todas as categorias
     */
    public void clear() {
        if (categories != null) {
            int size = categories.size();
            categories.clear();
            notifyItemRangeRemoved(0, size);
        }
    }
}

