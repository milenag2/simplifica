/**
 * chart-utils.js - Utilitários para criação e gerenciamento de gráficos
 * 
 * Este arquivo contém funções auxiliares para criar diferentes tipos de gráficos
 * usando a biblioteca Chart.js, incluindo gráficos de pizza, barras e linhas.
 * 
 * Funcionalidades:
 * - Criação de gráficos de categorias (pizza)
 * - Gráficos de evolução temporal (linha)
 * - Gráficos comparativos (barras)
 * - Configurações responsivas
 * - Temas e cores personalizadas
 */

// Configuração global do Chart.js
Chart.defaults.font.family = 'Inter, system-ui, -apple-system, sans-serif';
Chart.defaults.font.size = 12;
Chart.defaults.color = '#4A5568';

// Paleta de cores para os gráficos
const CHART_COLORS = [
    '#667eea', // Azul primário
    '#764ba2', // Roxo
    '#f093fb', // Rosa
    '#4facfe', // Azul claro
    '#43e97b', // Verde
    '#38ef7d', // Verde claro
    '#ffecd2', // Amarelo claro
    '#fcb69f', // Laranja claro
    '#ff9a9e', // Rosa claro
    '#a8edea'  // Azul muito claro
];

// Cores específicas para receitas e despesas
const INCOME_COLOR = '#48BB78';
const EXPENSE_COLOR = '#F56565';
const BALANCE_COLOR = '#4299E1';

/**
 * Cria um gráfico de pizza para mostrar distribuição por categorias
 * 
 * @param {string} canvasId - ID do elemento canvas
 * @param {Array} data - Array de objetos com {category, amount, type}
 * @param {string} title - Título do gráfico
 * @returns {Chart} Instância do gráfico criado
 */
function createCategoryPieChart(canvasId, data, title = 'Gastos por Categoria') {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
        console.error(`Canvas com ID '${canvasId}' não encontrado`);
        return null;
    }

    // Processa os dados para o formato do Chart.js
    const processedData = processCategoryData(data);
    
    const config = {
        type: 'pie',
        data: {
            labels: processedData.labels,
            datasets: [{
                data: processedData.values,
                backgroundColor: processedData.colors,
                borderColor: '#ffffff',
                borderWidth: 2,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: title,
                    font: {
                        size: 16,
                        weight: 'bold'
                    },
                    padding: 20
                },
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        usePointStyle: true,
                        font: {
                            size: 11
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: R$ ${value.toFixed(2)} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                animateScale: true,
                duration: 1000
            }
        }
    };

    return new Chart(ctx, config);
}

/**
 * Cria um gráfico de barras para comparar receitas e despesas
 * 
 * @param {string} canvasId - ID do elemento canvas
 * @param {Array} data - Array de objetos com dados mensais
 * @param {string} title - Título do gráfico
 * @returns {Chart} Instância do gráfico criado
 */
function createIncomeExpenseChart(canvasId, data, title = 'Receitas vs Despesas') {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
        console.error(`Canvas com ID '${canvasId}' não encontrado`);
        return null;
    }

    // Processa os dados para o formato do Chart.js
    const processedData = processIncomeExpenseData(data);
    
    const config = {
        type: 'bar',
        data: {
            labels: processedData.labels,
            datasets: [
                {
                    label: 'Receitas',
                    data: processedData.income,
                    backgroundColor: INCOME_COLOR,
                    borderColor: INCOME_COLOR,
                    borderWidth: 1,
                    borderRadius: 4,
                    borderSkipped: false
                },
                {
                    label: 'Despesas',
                    data: processedData.expenses,
                    backgroundColor: EXPENSE_COLOR,
                    borderColor: EXPENSE_COLOR,
                    borderWidth: 1,
                    borderRadius: 4,
                    borderSkipped: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: title,
                    font: {
                        size: 16,
                        weight: 'bold'
                    },
                    padding: 20
                },
                legend: {
                    position: 'top',
                    labels: {
                        padding: 15,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.dataset.label || '';
                            const value = context.parsed.y || 0;
                            return `${label}: R$ ${value.toFixed(2)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 11
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#E2E8F0'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toFixed(0);
                        },
                        font: {
                            size: 11
                        }
                    }
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeInOutQuart'
            }
        }
    };

    return new Chart(ctx, config);
}

/**
 * Cria um gráfico de linha para mostrar evolução do saldo ao longo do tempo
 * 
 * @param {string} canvasId - ID do elemento canvas
 * @param {Array} data - Array de objetos com dados temporais
 * @param {string} title - Título do gráfico
 * @returns {Chart} Instância do gráfico criado
 */
function createBalanceEvolutionChart(canvasId, data, title = 'Evolução do Saldo') {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
        console.error(`Canvas com ID '${canvasId}' não encontrado`);
        return null;
    }

    // Processa os dados para o formato do Chart.js
    const processedData = processBalanceData(data);
    
    const config = {
        type: 'line',
        data: {
            labels: processedData.labels,
            datasets: [{
                label: 'Saldo',
                data: processedData.values,
                borderColor: BALANCE_COLOR,
                backgroundColor: BALANCE_COLOR + '20', // 20% de opacidade
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: BALANCE_COLOR,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: title,
                    font: {
                        size: 16,
                        weight: 'bold'
                    },
                    padding: 20
                },
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed.y || 0;
                            return `Saldo: R$ ${value.toFixed(2)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 11
                        }
                    }
                },
                y: {
                    grid: {
                        color: '#E2E8F0'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toFixed(0);
                        },
                        font: {
                            size: 11
                        }
                    }
                }
            },
            animation: {
                duration: 1500,
                easing: 'easeInOutQuart'
            }
        }
    };

    return new Chart(ctx, config);
}

/**
 * Processa dados de categorias para o formato do Chart.js
 * 
 * @param {Array} data - Dados brutos das categorias
 * @returns {Object} Dados processados
 */
function processCategoryData(data) {
    if (!data || data.length === 0) {
        return {
            labels: ['Sem dados'],
            values: [1],
            colors: ['#E2E8F0']
        };
    }

    // Agrupa por categoria e soma os valores
    const categoryMap = new Map();
    
    data.forEach(item => {
        const category = item.category || 'Outros';
        const amount = Math.abs(parseFloat(item.amount) || 0);
        
        if (categoryMap.has(category)) {
            categoryMap.set(category, categoryMap.get(category) + amount);
        } else {
            categoryMap.set(category, amount);
        }
    });

    // Ordena por valor (maior para menor)
    const sortedEntries = Array.from(categoryMap.entries())
        .sort((a, b) => b[1] - a[1]);

    const labels = sortedEntries.map(entry => entry[0]);
    const values = sortedEntries.map(entry => entry[1]);
    const colors = sortedEntries.map((_, index) => CHART_COLORS[index % CHART_COLORS.length]);

    return { labels, values, colors };
}

/**
 * Processa dados de receitas e despesas para o formato do Chart.js
 * 
 * @param {Array} data - Dados brutos mensais
 * @returns {Object} Dados processados
 */
function processIncomeExpenseData(data) {
    if (!data || data.length === 0) {
        const currentMonth = new Date().toLocaleDateString('pt-BR', { month: 'short' });
        return {
            labels: [currentMonth],
            income: [0],
            expenses: [0]
        };
    }

    const labels = data.map(item => item.month || 'Mês');
    const income = data.map(item => parseFloat(item.income) || 0);
    const expenses = data.map(item => Math.abs(parseFloat(item.expenses)) || 0);

    return { labels, income, expenses };
}

/**
 * Processa dados de saldo para o formato do Chart.js
 * 
 * @param {Array} data - Dados brutos de saldo
 * @returns {Object} Dados processados
 */
function processBalanceData(data) {
    if (!data || data.length === 0) {
        const currentMonth = new Date().toLocaleDateString('pt-BR', { month: 'short' });
        return {
            labels: [currentMonth],
            values: [0]
        };
    }

    const labels = data.map(item => item.period || 'Período');
    const values = data.map(item => parseFloat(item.balance) || 0);

    return { labels, values };
}

/**
 * Atualiza um gráfico existente com novos dados
 * 
 * @param {Chart} chart - Instância do gráfico
 * @param {Array} newData - Novos dados
 * @param {Function} processFunction - Função para processar os dados
 */
function updateChart(chart, newData, processFunction) {
    if (!chart || !newData) {
        console.error('Gráfico ou dados inválidos para atualização');
        return;
    }

    const processedData = processFunction(newData);
    
    chart.data.labels = processedData.labels;
    
    if (chart.data.datasets.length > 0) {
        if (processedData.values) {
            chart.data.datasets[0].data = processedData.values;
            if (processedData.colors) {
                chart.data.datasets[0].backgroundColor = processedData.colors;
            }
        } else if (processedData.income && processedData.expenses) {
            chart.data.datasets[0].data = processedData.income;
            chart.data.datasets[1].data = processedData.expenses;
        }
    }
    
    chart.update('active');
}

/**
 * Destrói um gráfico e libera recursos
 * 
 * @param {Chart} chart - Instância do gráfico
 */
function destroyChart(chart) {
    if (chart && typeof chart.destroy === 'function') {
        chart.destroy();
    }
}

/**
 * Redimensiona todos os gráficos na página
 * Útil para responsividade
 */
function resizeAllCharts() {
    Chart.helpers.each(Chart.instances, function(instance) {
        instance.resize();
    });
}

// Event listener para redimensionamento da janela
window.addEventListener('resize', function() {
    setTimeout(resizeAllCharts, 100);
});

// Exporta as funções para uso global
window.ChartUtils = {
    createCategoryPieChart,
    createIncomeExpenseChart,
    createBalanceEvolutionChart,
    updateChart,
    destroyChart,
    resizeAllCharts,
    processCategoryData,
    processIncomeExpenseData,
    processBalanceData,
    CHART_COLORS,
    INCOME_COLOR,
    EXPENSE_COLOR,
    BALANCE_COLOR
};

