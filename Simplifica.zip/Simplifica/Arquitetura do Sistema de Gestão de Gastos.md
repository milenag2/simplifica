# Arquitetura do Sistema de Gestão de Gastos

## 1. Visão Geral da Arquitetura

O sistema será composto por três componentes principais que trabalharão de forma integrada:

- **Backend (API RESTful):** Desenvolvido em Python com o framework Flask. Será responsável pela lógica de negócios, persistência de dados e exposição de APIs para o frontend web e o aplicativo Android.
- **Frontend Web:** Desenvolvido com HTML, CSS e JavaScript puro (ou uma biblioteca leve como Vue.js/React se necessário para complexidade da UI). Irá consumir as APIs do backend para exibir e gerenciar os dados.
- **Aplicativo Android:** Desenvolvido em Java. Também consumirá as APIs do backend para fornecer uma experiência móvel nativa.

```mermaid
graph TD
    A[Aplicativo Android] --> B(API RESTful - Backend Flask)
    C[Frontend Web (HTML/CSS/JS)] --> B
    B --> D[Banco de Dados (SQLite/PostgreSQL)]
```

## 2. Modelo de Dados

O modelo de dados será a base para o armazenamento e manipulação das informações. As principais entidades serão:

### 2.1. Usuário (User)
- `id` (PK): Identificador único do usuário.
- `username`: Nome de usuário para login.
- `password_hash`: Hash da senha do usuário.
- `email`: Endereço de e-mail do usuário.

### 2.2. Categoria (Category)
- `id` (PK): Identificador único da categoria.
- `user_id` (FK): Referência ao usuário proprietário da categoria.
- `name`: Nome da categoria (ex: Alimentação, Transporte, Salário).
- `type`: Tipo da categoria (receita ou despesa).

### 2.3. Transação (Transaction)
- `id` (PK): Identificador único da transação.
- `user_id` (FK): Referência ao usuário que registrou a transação.
- `category_id` (FK): Referência à categoria da transação.
- `description`: Descrição da transação (ex: Almoço no restaurante, Pagamento de salário).
- `amount`: Valor da transação (positivo para receita, negativo para despesa).
- `type`: Tipo da transação (receita ou despesa).
- `date`: Data da transação.
- `is_recurring`: Booleano indicando se é uma transação recorrente.
- `recurring_frequency`: Frequência da recorrência (ex: diário, semanal, mensal, anual) - Opcional.
- `recurring_end_date`: Data de término da recorrência - Opcional.

### 2.4. Recorrência (RecurringTransaction - Opcional, pode ser integrado em Transaction)
Se optarmos por uma tabela separada para recorrências, seria algo assim:
- `id` (PK): Identificador único da recorrência.
- `user_id` (FK): Referência ao usuário.
- `category_id` (FK): Referência à categoria.
- `description`: Descrição da transação recorrente.
- `amount`: Valor da transação recorrente.
- `type`: Tipo da transação (receita ou despesa).
- `start_date`: Data de início da recorrência.
- `frequency`: Frequência da recorrência (ex: diário, semanal, mensal, anual).
- `end_date`: Data de término da recorrência (opcional).

Para simplificar inicialmente, podemos integrar `is_recurring`, `recurring_frequency` e `recurring_end_date` diretamente na tabela `Transaction`.

## 3. APIs RESTful (Endpoints Propostos)

### 3.1. Autenticação
- `POST /api/register`: Registrar novo usuário.
- `POST /api/login`: Autenticar usuário e retornar token JWT.

### 3.2. Transações
- `GET /api/transactions`: Obter todas as transações do usuário.
- `GET /api/transactions/{id}`: Obter uma transação específica.
- `POST /api/transactions`: Adicionar nova transação.
- `PUT /api/transactions/{id}`: Atualizar transação existente.
- `DELETE /api/transactions/{id}`: Deletar transação.

### 3.3. Categorias
- `GET /api/categories`: Obter todas as categorias do usuário.
- `POST /api/categories`: Adicionar nova categoria.

### 3.4. Relatórios e Saldo
- `GET /api/balance/monthly`: Calcular saldo mensal.
- `GET /api/reports/daily`: Relatório diário de transações.
- `GET /api/reports/monthly`: Relatório mensal de transações.
- `GET /api/reports/annual`: Relatório anual de transações.
- `GET /api/reports/categories`: Relatório de transações por categoria.

### 3.5. Recorrências (se implementado separadamente)
- `GET /api/recurring`: Obter todas as transações recorrentes.
- `POST /api/recurring`: Adicionar nova transação recorrente.
- `PUT /api/recurring/{id}`: Atualizar transação recorrente.
- `DELETE /api/recurring/{id}`: Deletar transação recorrente.

Este documento servirá como base para o desenvolvimento das próximas fases.

