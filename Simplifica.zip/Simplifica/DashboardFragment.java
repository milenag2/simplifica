package com.expensetracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * DashboardFragment - Fragmento que exibe o dashboard financeiro
 * 
 * Este fragmento mostra um resumo das finanças do usuário, incluindo:
 * - Receitas do mês atual
 * - Despesas do mês atual  
 * - Saldo mensal
 * - Lista de transações recentes
 * - Botões de ação rápida
 * 
 * Funcionalidades:
 * - Carregamento automático dos dados ao abrir
 * - Atualização em tempo real dos valores
 * - Navegação para outras seções
 * - Ações rápidas para adicionar transações
 */
public class DashboardFragment extends Fragment {
    
    // Elementos da interface
    private TextView monthlyIncomeText;
    private TextView monthlyExpenseText;
    private TextView monthlyBalanceText;
    private RecyclerView recentTransactionsList;
    private Button viewAllTransactionsBtn;
    private Button addTransactionFab;
    
    // Adaptador para a lista de transações recentes
    private TransactionAdapter recentTransactionsAdapter;
    
    // Gerenciador de API para comunicação com o backend
    private ApiManager apiManager;
    
    // Lista de transações recentes
    private List<Transaction> recentTransactions;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Infla o layout do fragmento
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        
        // Inicializa os componentes
        initializeViews(view);
        setupRecyclerView();
        setupClickListeners();
        
        // Inicializa o gerenciador de API
        apiManager = new ApiManager(getContext());
        
        // Inicializa a lista de transações
        recentTransactions = new ArrayList<>();
        
        return view;
    }
    
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        // Carrega os dados do dashboard
        loadDashboardData();
    }
    
    /**
     * Inicializa as referências dos elementos da interface
     * 
     * @param view View raiz do fragmento
     */
    private void initializeViews(View view) {
        monthlyIncomeText = view.findViewById(R.id.monthly_income);
        monthlyExpenseText = view.findViewById(R.id.monthly_expense);
        monthlyBalanceText = view.findViewById(R.id.monthly_balance);
        recentTransactionsList = view.findViewById(R.id.recent_transactions_list);
        viewAllTransactionsBtn = view.findViewById(R.id.view_all_transactions);
        addTransactionFab = view.findViewById(R.id.add_transaction_fab);
    }
    
    /**
     * Configura o RecyclerView para exibir as transações recentes
     */
    private void setupRecyclerView() {
        recentTransactionsList.setLayoutManager(new LinearLayoutManager(getContext()));
        recentTransactionsAdapter = new TransactionAdapter(recentTransactions, new TransactionAdapter.OnTransactionClickListener() {
            @Override
            public void onTransactionClick(Transaction transaction) {
                // Abre a tela de detalhes/edição da transação
                openTransactionDetails(transaction);
            }
            
            @Override
            public void onTransactionEdit(Transaction transaction) {
                // Abre a tela de edição da transação
                editTransaction(transaction);
            }
            
            @Override
            public void onTransactionDelete(Transaction transaction) {
                // Confirma e exclui a transação
                deleteTransaction(transaction);
            }
        });
        recentTransactionsList.setAdapter(recentTransactionsAdapter);
    }
    
    /**
     * Configura os listeners de clique dos botões
     */
    private void setupClickListeners() {
        // Botão para ver todas as transações
        viewAllTransactionsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToTransactions();
            }
        });
        
        // Botão para adicionar nova transação
        addTransactionFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddTransaction();
            }
        });
    }
    
    /**
     * Carrega todos os dados necessários para o dashboard
     */
    private void loadDashboardData() {
        loadMonthlyBalance();
        loadRecentTransactions();
    }
    
    /**
     * Carrega o saldo mensal (receitas, despesas e saldo total)
     */
    private void loadMonthlyBalance() {
        apiManager.getMonthlyBalance(new ApiManager.ApiCallback<BalanceResponse>() {
            @Override
            public void onSuccess(BalanceResponse balance) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateBalanceCards(balance);
                        }
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showError("Erro ao carregar saldo: " + error);
                        }
                    });
                }
            }
        });
    }
    
    /**
     * Carrega as transações mais recentes para exibir no dashboard
     */
    private void loadRecentTransactions() {
        apiManager.getRecentTransactions(5, new ApiManager.ApiCallback<List<Transaction>>() {
            @Override
            public void onSuccess(List<Transaction> transactions) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateRecentTransactions(transactions);
                        }
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showError("Erro ao carregar transações: " + error);
                        }
                    });
                }
            }
        });
    }
    
    /**
     * Atualiza os cards de saldo com os dados recebidos da API
     * 
     * @param balance Dados de saldo mensal
     */
    private void updateBalanceCards(BalanceResponse balance) {
        // Formata e exibe as receitas
        String incomeText = String.format(getString(R.string.currency_format), balance.getIncomeTotal());
        monthlyIncomeText.setText(incomeText);
        
        // Formata e exibe as despesas
        String expenseText = String.format(getString(R.string.currency_format), balance.getExpenseTotal());
        monthlyExpenseText.setText(expenseText);
        
        // Formata e exibe o saldo
        String balanceText = String.format(getString(R.string.currency_format), balance.getBalance());
        monthlyBalanceText.setText(balanceText);
        
        // Atualiza a cor do saldo baseado no valor (positivo/negativo)
        int balanceColor;
        if (balance.getBalance() > 0) {
            balanceColor = getResources().getColor(R.color.balance_positive);
        } else if (balance.getBalance() < 0) {
            balanceColor = getResources().getColor(R.color.balance_negative);
        } else {
            balanceColor = getResources().getColor(R.color.balance_neutral);
        }
        monthlyBalanceText.setTextColor(balanceColor);
    }
    
    /**
     * Atualiza a lista de transações recentes
     * 
     * @param transactions Lista de transações recentes
     */
    private void updateRecentTransactions(List<Transaction> transactions) {
        recentTransactions.clear();
        recentTransactions.addAll(transactions);
        recentTransactionsAdapter.notifyDataSetChanged();
    }
    
    /**
     * Navega para a tela de transações
     */
    private void navigateToTransactions() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).navigateToFragment("transactions");
        }
    }
    
    /**
     * Abre a tela para adicionar uma nova transação
     */
    private void openAddTransaction() {
        // TODO: Implementar navegação para tela de adicionar transação
        // Por enquanto, mostra um toast
        Toast.makeText(getContext(), "Adicionar nova transação", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Abre os detalhes de uma transação específica
     * 
     * @param transaction Transação a ser visualizada
     */
    private void openTransactionDetails(Transaction transaction) {
        // TODO: Implementar navegação para tela de detalhes da transação
        Toast.makeText(getContext(), "Detalhes: " + transaction.getDescription(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Abre a tela de edição de uma transação
     * 
     * @param transaction Transação a ser editada
     */
    private void editTransaction(Transaction transaction) {
        // TODO: Implementar navegação para tela de edição da transação
        Toast.makeText(getContext(), "Editar: " + transaction.getDescription(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Exclui uma transação após confirmação
     * 
     * @param transaction Transação a ser excluída
     */
    private void deleteTransaction(Transaction transaction) {
        // TODO: Implementar confirmação e exclusão da transação
        Toast.makeText(getContext(), "Excluir: " + transaction.getDescription(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Exibe uma mensagem de erro para o usuário
     * 
     * @param message Mensagem de erro
     */
    private void showError(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }
    
    /**
     * Método público para atualizar os dados do dashboard
     * Pode ser chamado por outras partes do app quando dados são modificados
     */
    public void refreshData() {
        loadDashboardData();
    }
    
    /**
     * Método chamado quando o fragmento fica visível
     * Atualiza os dados para garantir que estejam sempre atualizados
     */
    @Override
    public void onResume() {
        super.onResume();
        refreshData();
    }
}

