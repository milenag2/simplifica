package com.expensetracker;

/**
 * BalanceResponse - Modelo de dados para resposta de saldo mensal
 * 
 * Esta classe encapsula os dados retornados pela API quando solicitado
 * o saldo mensal do usuário, incluindo total de receitas, despesas e saldo.
 * 
 * Atributos:
 * - Total de receitas do mês
 * - Total de despesas do mês
 * - Saldo mensal (receitas - despesas)
 */
public class BalanceResponse {
    
    private double incomeTotal;
    private double expenseTotal;
    private double balance;
    
    /**
     * Construtor padrão
     */
    public BalanceResponse() {
    }
    
    /**
     * Construtor com parâmetros
     * 
     * @param incomeTotal Total de receitas
     * @param expenseTotal Total de despesas
     * @param balance Saldo (receitas - despesas)
     */
    public BalanceResponse(double incomeTotal, double expenseTotal, double balance) {
        this.incomeTotal = incomeTotal;
        this.expenseTotal = expenseTotal;
        this.balance = balance;
    }
    
    // Getters e Setters
    
    public double getIncomeTotal() {
        return incomeTotal;
    }
    
    public void setIncomeTotal(double incomeTotal) {
        this.incomeTotal = incomeTotal;
    }
    
    public double getExpenseTotal() {
        return expenseTotal;
    }
    
    public void setExpenseTotal(double expenseTotal) {
        this.expenseTotal = expenseTotal;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public void setBalance(double balance) {
        this.balance = balance;
    }
    
    // Métodos auxiliares
    
    /**
     * Retorna o total de receitas formatado como moeda
     * 
     * @return Receitas formatadas (ex: "R$ 1.234,56")
     */
    public String getFormattedIncomeTotal() {
        return String.format("R$ %.2f", incomeTotal);
    }
    
    /**
     * Retorna o total de despesas formatado como moeda
     * 
     * @return Despesas formatadas (ex: "R$ 1.234,56")
     */
    public String getFormattedExpenseTotal() {
        return String.format("R$ %.2f", expenseTotal);
    }
    
    /**
     * Retorna o saldo formatado como moeda
     * 
     * @return Saldo formatado (ex: "R$ 1.234,56")
     */
    public String getFormattedBalance() {
        return String.format("R$ %.2f", balance);
    }
    
    /**
     * Verifica se o saldo é positivo
     * 
     * @return true se positivo, false caso contrário
     */
    public boolean isPositiveBalance() {
        return balance > 0;
    }
    
    /**
     * Verifica se o saldo é negativo
     * 
     * @return true se negativo, false caso contrário
     */
    public boolean isNegativeBalance() {
        return balance < 0;
    }
    
    /**
     * Verifica se o saldo é zero
     * 
     * @return true se zero, false caso contrário
     */
    public boolean isZeroBalance() {
        return balance == 0;
    }
    
    /**
     * Retorna a porcentagem de gastos em relação às receitas
     * 
     * @return Porcentagem (0-100) ou 0 se não houver receitas
     */
    public double getExpensePercentage() {
        if (incomeTotal == 0) {
            return 0;
        }
        return (expenseTotal / incomeTotal) * 100;
    }
    
    /**
     * Retorna a taxa de economia (saldo/receitas)
     * 
     * @return Porcentagem de economia ou 0 se não houver receitas
     */
    public double getSavingsRate() {
        if (incomeTotal == 0) {
            return 0;
        }
        return (balance / incomeTotal) * 100;
    }
    
    @Override
    public String toString() {
        return "BalanceResponse{" +
                "incomeTotal=" + incomeTotal +
                ", expenseTotal=" + expenseTotal +
                ", balance=" + balance +
                '}';
    }
}

