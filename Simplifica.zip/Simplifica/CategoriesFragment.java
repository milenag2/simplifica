package com.expensetracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.util.ArrayList;
import java.util.List;

/**
 * CategoriesFragment - Fragmento para gerenciar categorias
 * 
 * Este fragmento permite ao usuário visualizar, adicionar, editar e excluir
 * categorias para organizar suas transações financeiras.
 * 
 * Funcionalidades:
 * - Lista de categorias em grid
 * - Separação entre categorias de receita e despesa
 * - Ações de adicionar, editar e excluir
 * - Atualização por pull-to-refresh
 * - Interface visual diferenciada por tipo
 */
public class CategoriesFragment extends Fragment {
    
    // Elementos da interface
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView categoriesList;
    private Button addCategoryButton;
    private View emptyStateView;
    
    // Adaptador para a lista de categorias
    private CategoryAdapter categoriesAdapter;
    
    // Gerenciador de API
    private ApiManager apiManager;
    
    // Lista de categorias
    private List<Category> categories;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_categories, container, false);
        
        // Inicializa os componentes
        initializeViews(view);
        setupRecyclerView();
        setupSwipeRefresh();
        setupClickListeners();
        
        // Inicializa o gerenciador de API
        apiManager = new ApiManager(getContext());
        
        // Inicializa a lista de categorias
        categories = new ArrayList<>();
        
        return view;
    }
    
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        // Carrega as categorias
        loadCategories();
    }
    
    /**
     * Inicializa as referências dos elementos da interface
     */
    private void initializeViews(View view) {
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout);
        categoriesList = view.findViewById(R.id.categories_list);
        addCategoryButton = view.findViewById(R.id.add_category_button);
        emptyStateView = view.findViewById(R.id.empty_state_view);
    }
    
    /**
     * Configura o RecyclerView para exibir as categorias em grid
     */
    private void setupRecyclerView() {
        // Usa GridLayoutManager com 2 colunas
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        categoriesList.setLayoutManager(gridLayoutManager);
        
        categoriesAdapter = new CategoryAdapter(categories, new CategoryAdapter.OnCategoryClickListener() {
            @Override
            public void onCategoryClick(Category category) {
                openCategoryDetails(category);
            }
            
            @Override
            public void onCategoryEdit(Category category) {
                editCategory(category);
            }
            
            @Override
            public void onCategoryDelete(Category category) {
                confirmDeleteCategory(category);
            }
        });
        categoriesList.setAdapter(categoriesAdapter);
    }
    
    /**
     * Configura o SwipeRefreshLayout
     */
    private void setupSwipeRefresh() {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadCategories();
            }
        });
        
        // Define as cores do indicador de refresh
        swipeRefreshLayout.setColorSchemeResources(
                R.color.primary_color,
                R.color.accent_color
        );
    }
    
    /**
     * Configura os listeners de clique
     */
    private void setupClickListeners() {
        addCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddCategory();
            }
        });
    }
    
    /**
     * Carrega todas as categorias do usuário
     */
    private void loadCategories() {
        // Mostra o indicador de loading se não estiver fazendo refresh
        if (!swipeRefreshLayout.isRefreshing()) {
            showLoading(true);
        }
        
        apiManager.getCategories(new ApiManager.ApiCallback<List<Category>>() {
            @Override
            public void onSuccess(List<Category> loadedCategories) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateCategoriesList(loadedCategories);
                            showLoading(false);
                            swipeRefreshLayout.setRefreshing(false);
                        }
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showError("Erro ao carregar categorias: " + error);
                            showLoading(false);
                            swipeRefreshLayout.setRefreshing(false);
                        }
                    });
                }
            }
        });
    }
    
    /**
     * Atualiza a lista de categorias na interface
     */
    private void updateCategoriesList(List<Category> newCategories) {
        categories.clear();
        categories.addAll(newCategories);
        categoriesAdapter.notifyDataSetChanged();
        
        // Mostra/esconde o estado vazio
        if (categories.isEmpty()) {
            showEmptyState(true);
        } else {
            showEmptyState(false);
        }
    }
    
    /**
     * Abre a tela para adicionar uma nova categoria
     */
    private void openAddCategory() {
        // TODO: Implementar navegação para tela de adicionar categoria
        Toast.makeText(getContext(), "Adicionar nova categoria", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Abre os detalhes de uma categoria
     */
    private void openCategoryDetails(Category category) {
        // TODO: Implementar navegação para tela de detalhes
        Toast.makeText(getContext(), "Detalhes: " + category.getName(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Abre a tela de edição de uma categoria
     */
    private void editCategory(Category category) {
        // TODO: Implementar navegação para tela de edição
        Toast.makeText(getContext(), "Editar: " + category.getName(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Confirma e exclui uma categoria
     */
    private void confirmDeleteCategory(Category category) {
        // TODO: Implementar dialog de confirmação
        deleteCategory(category);
    }
    
    /**
     * Exclui uma categoria
     */
    private void deleteCategory(Category category) {
        // TODO: Implementar método deleteCategory no ApiManager
        Toast.makeText(getContext(), "Funcionalidade de exclusão será implementada", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Mostra/esconde o indicador de loading
     */
    private void showLoading(boolean show) {
        // TODO: Implementar indicador de loading
    }
    
    /**
     * Mostra/esconde o estado vazio
     */
    private void showEmptyState(boolean show) {
        if (show) {
            emptyStateView.setVisibility(View.VISIBLE);
            categoriesList.setVisibility(View.GONE);
        } else {
            emptyStateView.setVisibility(View.GONE);
            categoriesList.setVisibility(View.VISIBLE);
        }
    }
    
    /**
     * Exibe uma mensagem de erro
     */
    private void showError(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }
    
    /**
     * Exibe uma mensagem de sucesso
     */
    private void showSuccess(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Método público para atualizar as categorias
     */
    public void refreshCategories() {
        loadCategories();
    }
    
    /**
     * Método chamado quando o fragmento fica visível
     */
    @Override
    public void onResume() {
        super.onResume();
        // Atualiza as categorias quando o fragmento fica visível
        refreshCategories();
    }
    
    /**
     * Limpa recursos quando o fragmento é destruído
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (apiManager != null) {
            apiManager.shutdown();
        }
    }
}

