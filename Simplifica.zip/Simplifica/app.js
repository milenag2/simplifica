/**
 * Aplicação de Gestão de Gastos - JavaScript Principal
 * 
 * Este arquivo contém toda a lógica frontend da aplicação,
 * incluindo navegação, comunicação com a API, manipulação de dados
 * e geração de gráficos.
 */

// Configurações globais
const API_BASE_URL = '/api';
let currentUser = { id: 1 }; // Simulando usuário logado (ID fixo para demonstração)
let categories = [];
let transactions = [];
let charts = {};

// Elementos DOM principais
const elements = {
    // Navegação
    navButtons: document.querySelectorAll('.nav-btn'),
    sections: document.querySelectorAll('.section'),
    
    // Dashboard
    monthlyIncome: document.getElementById('monthly-income'),
    monthlyExpense: document.getElementById('monthly-expense'),
    monthlyBalance: document.getElementById('monthly-balance'),
    categoryChart: document.getElementById('categoryChart'),
    monthlyChart: document.getElementById('monthlyChart'),
    
    // Transações
    addTransactionBtn: document.getElementById('add-transaction-btn'),
    transactionsList: document.getElementById('transactions-list'),
    filterType: document.getElementById('filter-type'),
    filterCategory: document.getElementById('filter-category'),
    filterStartDate: document.getElementById('filter-start-date'),
    filterEndDate: document.getElementById('filter-end-date'),
    applyFilters: document.getElementById('apply-filters'),
    
    // Categorias
    addCategoryBtn: document.getElementById('add-category-btn'),
    categoriesGrid: document.getElementById('categories-grid'),
    
    // Relatórios
    reportType: document.getElementById('report-type'),
    reportMonth: document.getElementById('report-month'),
    reportYear: document.getElementById('report-year'),
    generateReport: document.getElementById('generate-report'),
    reportContent: document.getElementById('report-content'),
    
    // Modais
    transactionModal: document.getElementById('transaction-modal'),
    categoryModal: document.getElementById('category-modal'),
    loading: document.getElementById('loading'),
    
    // Formulários
    transactionForm: document.getElementById('transaction-form'),
    categoryForm: document.getElementById('category-form')
};

/**
 * Inicialização da aplicação
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('Iniciando aplicação de gestão de gastos...');
    
    // Configura event listeners
    setupEventListeners();
    
    // Carrega dados iniciais
    loadInitialData();
    
    // Define data atual nos campos de data
    setDefaultDates();
});

/**
 * Configura todos os event listeners da aplicação
 */
function setupEventListeners() {
    // Navegação entre seções
    elements.navButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const section = btn.dataset.section;
            navigateToSection(section);
        });
    });
    
    // Botões de adicionar
    elements.addTransactionBtn.addEventListener('click', () => openTransactionModal());
    elements.addCategoryBtn.addEventListener('click', () => openCategoryModal());
    
    // Filtros
    elements.applyFilters.addEventListener('click', applyTransactionFilters);
    
    // Relatórios
    elements.generateReport.addEventListener('click', generateReport);
    
    // Formulários
    elements.transactionForm.addEventListener('submit', handleTransactionSubmit);
    elements.categoryForm.addEventListener('submit', handleCategorySubmit);
    
    // Modais
    setupModalEventListeners();
    
    // Checkbox de transação recorrente
    const recurringCheckbox = document.getElementById('transaction-recurring');
    const recurringOptions = document.getElementById('recurring-options');
    
    recurringCheckbox.addEventListener('change', function() {
        recurringOptions.style.display = this.checked ? 'block' : 'none';
    });
}

/**
 * Configura event listeners dos modais
 */
function setupModalEventListeners() {
    // Fechar modais
    document.getElementById('close-transaction-modal').addEventListener('click', closeTransactionModal);
    document.getElementById('close-category-modal').addEventListener('click', closeCategoryModal);
    document.getElementById('cancel-transaction').addEventListener('click', closeTransactionModal);
    document.getElementById('cancel-category').addEventListener('click', closeCategoryModal);
    
    // Fechar modal clicando fora
    elements.transactionModal.addEventListener('click', (e) => {
        if (e.target === elements.transactionModal) closeTransactionModal();
    });
    
    elements.categoryModal.addEventListener('click', (e) => {
        if (e.target === elements.categoryModal) closeCategoryModal();
    });
}

/**
 * Navega para uma seção específica
 */
function navigateToSection(sectionName) {
    // Remove classe active de todos os botões e seções
    elements.navButtons.forEach(btn => btn.classList.remove('active'));
    elements.sections.forEach(section => section.classList.remove('active'));
    
    // Adiciona classe active ao botão e seção correspondentes
    document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');
    document.getElementById(sectionName).classList.add('active');
    
    // Carrega dados específicos da seção
    switch(sectionName) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'transactions':
            loadTransactions();
            break;
        case 'categories':
            loadCategories();
            break;
        case 'reports':
            // Relatórios são carregados sob demanda
            break;
    }
}

/**
 * Carrega dados iniciais da aplicação
 */
async function loadInitialData() {
    showLoading(true);
    
    try {
        // Carrega categorias primeiro (necessárias para outros componentes)
        await loadCategories();
        
        // Carrega transações
        await loadTransactions();
        
        // Carrega dados do dashboard
        await loadDashboardData();
        
        console.log('Dados iniciais carregados com sucesso');
    } catch (error) {
        console.error('Erro ao carregar dados iniciais:', error);
        showError('Erro ao carregar dados da aplicação');
    } finally {
        showLoading(false);
    }
}

/**
 * Carrega dados do dashboard
 */
async function loadDashboardData() {
    try {
        // Carrega saldo mensal
        const balance = await fetchMonthlyBalance();
        updateBalanceCards(balance);
        // Carrega dados para gráficos
        loadDashboardCharts();
        
    } catch (error) {
        console.error('Erro ao carregar dados do dashboard:', error);
    }
}

/**
 * Busca o saldo mensal atual
 */
async function fetchMonthlyBalance() {
    const now = new Date();
    const response = await fetch(`${API_BASE_URL}/balance/monthly?user_id=${currentUser.id}&year=${now.getFullYear()}&month=${now.getMonth() + 1}`);
    
    if (!response.ok) {
        throw new Error('Erro ao buscar saldo mensal');
    }
    
    return await response.json();
}

/**
 * Atualiza os cards de saldo no dashboard
 */
function updateBalanceCards(balanceData) {
    elements.monthlyIncome.textContent = formatCurrency(balanceData.income_total);
    elements.monthlyExpense.textContent = formatCurrency(balanceData.expense_total);
    elements.monthlyBalance.textContent = formatCurrency(balanceData.balance);
    
    // Atualiza cor do saldo baseado no valor
    const balanceCard = elements.monthlyBalance.closest('.card');
    balanceCard.classList.remove('positive', 'negative');
    balanceCard.classList.add(balanceData.balance >= 0 ? 'positive' : 'negative');
}

/**
 * Carrega e renderiza os gráficos
 */
async function loadCharts() {
    try {
        // Gráfico de categorias
        await loadCategoryChart();
        
        // Gráfico mensal
        await loadMonthlyChart();
        
    } catch (error) {
        console.error('Erro ao carregar gráficos:', error);
    }
}

/**
 * Carrega o gráfico de gastos por categoria
 */
async function loadCategoryChart() {
    try {
        const response = await fetch(`${API_BASE_URL}/reports/categories?user_id=${currentUser.id}&type=expense`);
        const data = await response.json();
        
        if (data.success && data.category_data.length > 0) {
            const labels = data.category_data.map(item => item.category_name);
            const values = data.category_data.map(item => Math.abs(item.total_amount));
            
            // Destrói gráfico anterior se existir
            if (charts.categoryChart) {
                charts.categoryChart.destroy();
            }
            
            // Cria novo gráfico
            charts.categoryChart = new Chart(elements.categoryChart, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: values,
                        backgroundColor: [
                            '#FF6384',
                            '#36A2EB',
                            '#FFCE56',
                            '#4BC0C0',
                            '#9966FF',
                            '#FF9F40',
                            '#FF6384',
                            '#C9CBCF'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        } else {
            // Mostra mensagem de dados vazios
            elements.categoryChart.parentElement.innerHTML = '<p class="empty-state">Nenhum dado de categoria disponível</p>';
        }
    } catch (error) {
        console.error('Erro ao carregar gráfico de categorias:', error);
    }
}

/**
 * Carrega o gráfico de evolução mensal
 */
async function loadMonthlyChart() {
    try {
        const currentYear = new Date().getFullYear();
        const response = await fetch(`${API_BASE_URL}/reports/annual?user_id=${currentUser.id}&year=${currentYear}`);
        const data = await response.json();
        
        if (data.success) {
            const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const incomeData = [];
            const expenseData = [];
            
            for (let i = 1; i <= 12; i++) {
                const monthData = data.monthly_data[i];
                incomeData.push(monthData.income_total);
                expenseData.push(Math.abs(monthData.expense_total));
            }
            
            // Destrói gráfico anterior se existir
            if (charts.monthlyChart) {
                charts.monthlyChart.destroy();
            }
            
            // Cria novo gráfico
            charts.monthlyChart = new Chart(elements.monthlyChart, {
                type: 'line',
                data: {
                    labels: months,
                    datasets: [{
                        label: 'Receitas',
                        data: incomeData,
                        borderColor: '#4CAF50',
                        backgroundColor: 'rgba(76, 175, 80, 0.1)',
                        tension: 0.4
                    }, {
                        label: 'Despesas',
                        data: expenseData,
                        borderColor: '#f44336',
                        backgroundColor: 'rgba(244, 67, 54, 0.1)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return formatCurrency(value);
                                }
                            }
                        }
                    }
                }
            });
        }
    } catch (error) {
        console.error('Erro ao carregar gráfico mensal:', error);
    }
}

/**
 * Carrega as categorias
 */
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE_URL}/categories?user_id=${currentUser.id}`);
        const data = await response.json();
        
        if (data.success) {
            categories = data.categories;
            renderCategories();
            updateCategorySelects();
        }
    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
    }
}

/**
 * Renderiza a lista de categorias
 */
function renderCategories() {
    if (categories.length === 0) {
        elements.categoriesGrid.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-tags"></i>
                <h3>Nenhuma categoria encontrada</h3>
                <p>Crie sua primeira categoria para começar a organizar suas transações</p>
            </div>
        `;
        return;
    }
    
    elements.categoriesGrid.innerHTML = categories.map(category => `
        <div class="category-item fade-in">
            <div class="category-icon ${category.type}">
                <i class="fas ${category.type === 'income' ? 'fa-arrow-up' : 'fa-arrow-down'}"></i>
            </div>
            <div class="category-name">${category.name}</div>
            <div class="category-type">${category.type === 'income' ? 'Receita' : 'Despesa'}</div>
            <div class="category-actions" style="margin-top: 1rem;">
                <button class="action-btn" onclick="editCategory(${category.id})" title="Editar">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-btn" onclick="deleteCategory(${category.id})" title="Excluir">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

/**
 * Atualiza os selects de categoria nos formulários
 */
function updateCategorySelects() {
    const selects = [elements.filterCategory, document.getElementById('transaction-category')];
    
    selects.forEach(select => {
        if (!select) return;
        
        // Mantém a primeira opção (placeholder)
        const firstOption = select.querySelector('option[value=""]');
        select.innerHTML = '';
        if (firstOption) {
            select.appendChild(firstOption);
        }
        
        // Adiciona categorias
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = `${category.name} (${category.type === 'income' ? 'Receita' : 'Despesa'})`;
            select.appendChild(option);
        });
    });
}

/**
 * Carrega as transações
 */
async function loadTransactions(filters = {}) {
    try {
        let url = `${API_BASE_URL}/transactions?user_id=${currentUser.id}`;
        
        // Adiciona filtros à URL
        Object.keys(filters).forEach(key => {
            if (filters[key]) {
                url += `&${key}=${encodeURIComponent(filters[key])}`;
            }
        });
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            transactions = data.transactions;
            renderTransactions();
        }
    } catch (error) {
        console.error('Erro ao carregar transações:', error);
    }
}

/**
 * Renderiza a lista de transações
 */
function renderTransactions() {
    if (transactions.length === 0) {
        elements.transactionsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exchange-alt"></i>
                <h3>Nenhuma transação encontrada</h3>
                <p>Adicione sua primeira transação para começar a controlar suas finanças</p>
            </div>
        `;
        return;
    }
    
    elements.transactionsList.innerHTML = transactions.map(transaction => `
        <div class="transaction-item fade-in">
            <div class="transaction-info">
                <div class="transaction-description">${transaction.description}</div>
                <div class="transaction-meta">
                    ${transaction.category_name} • ${formatDate(transaction.date)}
                    ${transaction.is_recurring ? ' • <i class="fas fa-repeat" title="Recorrente"></i>' : ''}
                </div>
            </div>
            <div class="transaction-amount ${transaction.type}">
                ${transaction.type === 'income' ? '+' : '-'}${formatCurrency(Math.abs(transaction.amount))}
            </div>
            <div class="transaction-actions">
                <button class="action-btn" onclick="editTransaction(${transaction.id})" title="Editar">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-btn" onclick="deleteTransaction(${transaction.id})" title="Excluir">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

/**
 * Aplica filtros às transações
 */
function applyTransactionFilters() {
    const filters = {
        type: elements.filterType.value,
        category_id: elements.filterCategory.value,
        start_date: elements.filterStartDate.value,
        end_date: elements.filterEndDate.value
    };
    
    loadTransactions(filters);
}

/**
 * Abre o modal de transação
 */
function openTransactionModal(transaction = null) {
    const modal = elements.transactionModal;
    const form = elements.transactionForm;
    const title = document.getElementById('transaction-modal-title');
    
    // Reset do formulário
    form.reset();
    
    if (transaction) {
        // Modo edição
        title.textContent = 'Editar Transação';
        populateTransactionForm(transaction);
    } else {
        // Modo criação
        title.textContent = 'Nova Transação';
        // Define data atual
        document.getElementById('transaction-date').value = new Date().toISOString().split('T')[0];
    }
    
    modal.classList.add('active');
}

/**
 * Fecha o modal de transação
 */
function closeTransactionModal() {
    elements.transactionModal.classList.remove('active');
    elements.transactionForm.reset();
    document.getElementById('recurring-options').style.display = 'none';
}

/**
 * Popula o formulário de transação com dados existentes
 */
function populateTransactionForm(transaction) {
    document.getElementById('transaction-type').value = transaction.type;
    document.getElementById('transaction-category').value = transaction.category_id;
    document.getElementById('transaction-description').value = transaction.description;
    document.getElementById('transaction-amount').value = Math.abs(transaction.amount);
    document.getElementById('transaction-date').value = transaction.date.split('T')[0];
    document.getElementById('transaction-recurring').checked = transaction.is_recurring;
    
    if (transaction.is_recurring) {
        document.getElementById('recurring-options').style.display = 'block';
        document.getElementById('recurring-frequency').value = transaction.recurring_frequency || 'monthly';
        if (transaction.recurring_end_date) {
            document.getElementById('recurring-end-date').value = transaction.recurring_end_date.split('T')[0];
        }
    }
    
    // Armazena ID para edição
    elements.transactionForm.dataset.editId = transaction.id;
}

/**
 * Manipula o envio do formulário de transação
 */
async function handleTransactionSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = {
        user_id: currentUser.id,
        type: document.getElementById('transaction-type').value,
        category_id: parseInt(document.getElementById('transaction-category').value),
        description: document.getElementById('transaction-description').value,
        amount: parseFloat(document.getElementById('transaction-amount').value),
        date: document.getElementById('transaction-date').value,
        is_recurring: document.getElementById('transaction-recurring').checked,
        recurring_frequency: document.getElementById('recurring-frequency').value,
        recurring_end_date: document.getElementById('recurring-end-date').value || null
    };
    
    try {
        showLoading(true);
        
        const editId = e.target.dataset.editId;
        let response;
        
        if (editId) {
            // Edição
            response = await fetch(`${API_BASE_URL}/transactions/${editId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        } else {
            // Criação
            response = await fetch(`${API_BASE_URL}/transactions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        }
        
        const result = await response.json();
        
        if (result.success) {
            closeTransactionModal();
            await loadTransactions();
            await loadDashboardData();
            showSuccess(editId ? 'Transação atualizada com sucesso!' : 'Transação criada com sucesso!');
        } else {
            showError(result.error || 'Erro ao salvar transação');
        }
    } catch (error) {
        console.error('Erro ao salvar transação:', error);
        showError('Erro ao salvar transação');
    } finally {
        showLoading(false);
    }
}

/**
 * Abre o modal de categoria
 */
function openCategoryModal(category = null) {
    const modal = elements.categoryModal;
    const form = elements.categoryForm;
    const title = document.getElementById('category-modal-title');
    
    // Reset do formulário
    form.reset();
    
    if (category) {
        // Modo edição
        title.textContent = 'Editar Categoria';
        document.getElementById('category-name').value = category.name;
        document.getElementById('category-type').value = category.type;
        form.dataset.editId = category.id;
    } else {
        // Modo criação
        title.textContent = 'Nova Categoria';
        delete form.dataset.editId;
    }
    
    modal.classList.add('active');
}

/**
 * Fecha o modal de categoria
 */
function closeCategoryModal() {
    elements.categoryModal.classList.remove('active');
    elements.categoryForm.reset();
}

/**
 * Manipula o envio do formulário de categoria
 */
async function handleCategorySubmit(e) {
    e.preventDefault();
    
    const data = {
        user_id: currentUser.id,
        name: document.getElementById('category-name').value,
        type: document.getElementById('category-type').value
    };
    
    try {
        showLoading(true);
        
        const editId = e.target.dataset.editId;
        let response;
        
        if (editId) {
            // Edição
            response = await fetch(`${API_BASE_URL}/categories/${editId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        } else {
            // Criação
            response = await fetch(`${API_BASE_URL}/categories`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        }
        
        const result = await response.json();
        
        if (result.success) {
            closeCategoryModal();
            await loadCategories();
            showSuccess(editId ? 'Categoria atualizada com sucesso!' : 'Categoria criada com sucesso!');
        } else {
            showError(result.error || 'Erro ao salvar categoria');
        }
    } catch (error) {
        console.error('Erro ao salvar categoria:', error);
        showError('Erro ao salvar categoria');
    } finally {
        showLoading(false);
    }
}

/**
 * Edita uma transação
 */
async function editTransaction(id) {
    const transaction = transactions.find(t => t.id === id);
    if (transaction) {
        openTransactionModal(transaction);
    }
}

/**
 * Exclui uma transação
 */
async function deleteTransaction(id) {
    if (!confirm('Tem certeza que deseja excluir esta transação?')) {
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch(`${API_BASE_URL}/transactions/${id}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.success) {
            await loadTransactions();
            await loadDashboardData();
            showSuccess('Transação excluída com sucesso!');
        } else {
            showError('Erro ao excluir transação');
        }
    } catch (error) {
        console.error('Erro ao excluir transação:', error);
        showError('Erro ao excluir transação');
    } finally {
        showLoading(false);
    }
}

/**
 * Edita uma categoria
 */
async function editCategory(id) {
    const category = categories.find(c => c.id === id);
    if (category) {
        openCategoryModal(category);
    }
}

/**
 * Exclui uma categoria
 */
async function deleteCategory(id) {
    if (!confirm('Tem certeza que deseja excluir esta categoria?')) {
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch(`${API_BASE_URL}/categories/${id}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.success) {
            await loadCategories();
            showSuccess('Categoria excluída com sucesso!');
        } else {
            showError('Erro ao excluir categoria');
        }
    } catch (error) {
        console.error('Erro ao excluir categoria:', error);
        showError('Erro ao excluir categoria');
    } finally {
        showLoading(false);
    }
}

/**
 * Gera relatório baseado nos filtros selecionados
 */
async function generateReport() {
    const reportType = elements.reportType.value;
    const reportMonth = elements.reportMonth.value;
    const reportYear = elements.reportYear.value;
    
    try {
        showLoading(true);
        
        let url = `${API_BASE_URL}/reports/`;
        let params = `user_id=${currentUser.id}`;
        
        switch (reportType) {
            case 'monthly':
                if (!reportMonth) {
                    showError('Selecione um mês para o relatório mensal');
                    return;
                }
                const [year, month] = reportMonth.split('-');
                url += `monthly?${params}&year=${year}&month=${month}`;
                break;
                
            case 'annual':
                if (!reportYear) {
                    showError('Selecione um ano para o relatório anual');
                    return;
                }
                url += `annual?${params}&year=${reportYear}`;
                break;
                
            case 'category':
                url += `categories?${params}`;
                break;
        }
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            renderReport(data, reportType);
        } else {
            showError('Erro ao gerar relatório');
        }
    } catch (error) {
        console.error('Erro ao gerar relatório:', error);
        showError('Erro ao gerar relatório');
    } finally {
        showLoading(false);
    }
}

/**
 * Renderiza o relatório na tela
 */
function renderReport(data, type) {
    let html = '';
    
    switch (type) {
        case 'monthly':
            html = `
                <h3>Relatório Mensal - ${data.month}/${data.year}</h3>
                <div class="report-summary">
                    <div class="summary-item">
                        <strong>Total de Receitas:</strong> ${formatCurrency(data.income_total)}
                    </div>
                    <div class="summary-item">
                        <strong>Total de Despesas:</strong> ${formatCurrency(data.expense_total)}
                    </div>
                    <div class="summary-item">
                        <strong>Saldo:</strong> ${formatCurrency(data.balance)}
                    </div>
                    <div class="summary-item">
                        <strong>Total de Transações:</strong> ${data.transaction_count}
                    </div>
                </div>
            `;
            break;
            
        case 'annual':
            html = `
                <h3>Relatório Anual - ${data.year}</h3>
                <div class="report-summary">
                    <div class="summary-item">
                        <strong>Total de Receitas:</strong> ${formatCurrency(data.annual_income)}
                    </div>
                    <div class="summary-item">
                        <strong>Total de Despesas:</strong> ${formatCurrency(data.annual_expense)}
                    </div>
                    <div class="summary-item">
                        <strong>Saldo Anual:</strong> ${formatCurrency(data.annual_balance)}
                    </div>
                    <div class="summary-item">
                        <strong>Total de Transações:</strong> ${data.total_transactions}
                    </div>
                </div>
                <h4>Resumo Mensal</h4>
                <div class="monthly-breakdown">
                    ${Object.values(data.monthly_data).map(month => `
                        <div class="month-item">
                            <strong>Mês ${month.month}:</strong>
                            Receitas: ${formatCurrency(month.income_total)} |
                            Despesas: ${formatCurrency(month.expense_total)} |
                            Saldo: ${formatCurrency(month.balance)}
                        </div>
                    `).join('')}
                </div>
            `;
            break;
            
        case 'category':
            html = `
                <h3>Relatório por Categoria</h3>
                <div class="category-breakdown">
                    ${data.category_data.map(category => `
                        <div class="category-report-item">
                            <strong>${category.category_name}</strong> (${category.category_type === 'income' ? 'Receita' : 'Despesa'})
                            <br>
                            Total: ${formatCurrency(Math.abs(category.total_amount))} |
                            Transações: ${category.transaction_count}
                        </div>
                    `).join('')}
                </div>
            `;
            break;
    }
    
    elements.reportContent.innerHTML = html;
}

/**
 * Define datas padrão nos campos
 */
function setDefaultDates() {
    const today = new Date().toISOString().split('T')[0];
    const currentMonth = new Date().toISOString().slice(0, 7);
    const currentYear = new Date().getFullYear();
    
    // Data atual para transações
    const transactionDate = document.getElementById('transaction-date');
    if (transactionDate) {
        transactionDate.value = today;
    }
    
    // Mês atual para relatórios
    if (elements.reportMonth) {
        elements.reportMonth.value = currentMonth;
    }
    
    // Ano atual para relatórios
    if (elements.reportYear) {
        elements.reportYear.value = currentYear;
    }
}

/**
 * Mostra/esconde o loading
 */
function showLoading(show) {
    elements.loading.classList.toggle('active', show);
}

/**
 * Mostra mensagem de sucesso
 */
function showSuccess(message) {
    // Implementação simples com alert - pode ser melhorada com toast/notification
    alert(message);
}

/**
 * Mostra mensagem de erro
 */
function showError(message) {
    // Implementação simples com alert - pode ser melhorada com toast/notification
    alert('Erro: ' + message);
}

/**
 * Formata valor monetário
 */
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value || 0);
}

/**
 * Formata data
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}



/**
 * Carrega gráficos do dashboard
 */
async function loadDashboardCharts() {
    try {
        // Destrói gráficos existentes se houver
        if (charts.categoryChart) {
            charts.categoryChart.destroy();
        }
        if (charts.monthlyChart) {
            charts.monthlyChart.destroy();
        }
        
        // Carrega dados para gráfico de categorias
        const categoryData = await getCategoryChartData();
        if (categoryData && categoryData.length > 0) {
            charts.categoryChart = ChartUtils.createCategoryPieChart(
                'categoryChart',
                categoryData,
                'Gastos por Categoria'
            );
        }
        
        // Carrega dados para gráfico mensal
        const monthlyData = await getMonthlyChartData();
        if (monthlyData && monthlyData.length > 0) {
            charts.monthlyChart = ChartUtils.createIncomeExpenseChart(
                'monthlyChart',
                monthlyData,
                'Receitas vs Despesas'
            );
        }
        
    } catch (error) {
        console.error('Erro ao carregar gráficos:', error);
    }
}

/**
 * Obtém dados para o gráfico de categorias (despesas do mês atual)
 */
async function getCategoryChartData() {
    try {
        // Filtra transações do mês atual que são despesas
        const currentDate = new Date();
        const currentMonth = currentDate.getMonth() + 1;
        const currentYear = currentDate.getFullYear();
        
        const monthlyExpenses = transactions.filter(transaction => {
            const transactionDate = new Date(transaction.date);
            return transaction.type === 'expense' &&
                   transactionDate.getMonth() + 1 === currentMonth &&
                   transactionDate.getFullYear() === currentYear;
        });
        
        if (monthlyExpenses.length === 0) {
            return [];
        }
        
        // Agrupa por categoria
        const categoryTotals = {};
        monthlyExpenses.forEach(transaction => {
            const categoryName = getCategoryName(transaction.category_id);
            const amount = Math.abs(transaction.amount);
            
            if (categoryTotals[categoryName]) {
                categoryTotals[categoryName] += amount;
            } else {
                categoryTotals[categoryName] = amount;
            }
        });
        
        // Converte para formato do gráfico
        return Object.entries(categoryTotals).map(([category, amount]) => ({
            category,
            amount,
            type: 'expense'
        }));
        
    } catch (error) {
        console.error('Erro ao obter dados do gráfico de categorias:', error);
        return [];
    }
}

/**
 * Obtém dados para o gráfico mensal (últimos 6 meses)
 */
async function getMonthlyChartData() {
    try {
        const data = [];
        const currentDate = new Date();
        
        // Gera dados dos últimos 6 meses
        for (let i = 5; i >= 0; i--) {
            const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
            const monthName = date.toLocaleDateString('pt-BR', { month: 'short' });
            
            // Filtra transações do mês
            const monthTransactions = transactions.filter(transaction => {
                const transactionDate = new Date(transaction.date);
                return transactionDate.getMonth() === date.getMonth() &&
                       transactionDate.getFullYear() === date.getFullYear();
            });
            
            // Calcula totais
            const income = monthTransactions
                .filter(t => t.type === 'income')
                .reduce((sum, t) => sum + t.amount, 0);
                
            const expenses = monthTransactions
                .filter(t => t.type === 'expense')
                .reduce((sum, t) => sum + Math.abs(t.amount), 0);
            
            data.push({
                month: monthName,
                income: income,
                expenses: expenses
            });
        }
        
        return data;
        
    } catch (error) {
        console.error('Erro ao obter dados do gráfico mensal:', error);
        return [];
    }
}

/**
 * Atualiza gráficos quando os dados mudam
 */
function updateDashboardCharts() {
    // Recarrega os gráficos com novos dados
    loadDashboardCharts();
}

/**
 * Obtém o nome de uma categoria pelo ID
 */
function getCategoryName(categoryId) {
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : 'Categoria não encontrada';
}

/**
 * Destrói todos os gráficos para liberar memória
 */
function destroyAllCharts() {
    Object.values(charts).forEach(chart => {
        if (chart && typeof chart.destroy === 'function') {
            chart.destroy();
        }
    });
    charts = {};
}

// Event listener para redimensionamento da janela
window.addEventListener('resize', function() {
    // Redimensiona gráficos após um pequeno delay
    setTimeout(() => {
        if (window.ChartUtils) {
            ChartUtils.resizeAllCharts();
        }
    }, 100);
});

// Limpa gráficos quando a página é descarregada
window.addEventListener('beforeunload', function() {
    destroyAllCharts();
});

