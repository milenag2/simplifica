package com.expensetracker;

import android.content.Context;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ApiManager - Classe responsável pela comunicação com a API do backend
 * 
 * Esta classe centraliza todas as chamadas HTTP para o servidor Flask,
 * fornecendo métodos para gerenciar transações, categorias e relatórios.
 * 
 * Funcionalidades:
 * - Comunicação assíncrona com a API
 * - Tratamento de erros HTTP
 * - Serialização/deserialização JSON
 * - Callbacks para sucesso e erro
 * - Pool de threads para requisições
 */
public class ApiManager {
    
    private static final String TAG = "ApiManager";
    
    // URL base da API (configurável via strings.xml)
    private final String API_BASE_URL;
    
    // ID do usuário (simulado - em uma implementação real seria obtido da autenticação)
    private static final int USER_ID = 1;
    
    // Pool de threads para executar requisições em background
    private final ExecutorService executorService;
    
    // Contexto da aplicação
    private final Context context;
    
    /**
     * Construtor do ApiManager
     * 
     * @param context Contexto da aplicação
     */
    public ApiManager(Context context) {
        this.context = context;
        this.API_BASE_URL = context.getString(R.string.api_base_url);
        this.executorService = Executors.newFixedThreadPool(4);
    }
    
    /**
     * Interface para callbacks de requisições da API
     * 
     * @param <T> Tipo de dados retornado pela API
     */
    public interface ApiCallback<T> {
        void onSuccess(T result);
        void onError(String error);
    }
    
    /**
     * Obtém o saldo mensal do usuário
     * 
     * @param callback Callback para receber o resultado
     */
    public void getMonthlyBalance(ApiCallback<BalanceResponse> callback) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = API_BASE_URL + "/balance/monthly?user_id=" + USER_ID;
                    String response = makeGetRequest(url);
                    
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getBoolean("success")) {
                        BalanceResponse balance = new BalanceResponse(
                            jsonResponse.getDouble("income_total"),
                            jsonResponse.getDouble("expense_total"),
                            jsonResponse.getDouble("balance")
                        );
                        callback.onSuccess(balance);
                    } else {
                        callback.onError(jsonResponse.optString("error", "Erro desconhecido"));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao obter saldo mensal", e);
                    callback.onError("Erro de conexão: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Obtém todas as transações do usuário
     * 
     * @param callback Callback para receber o resultado
     */
    public void getTransactions(ApiCallback<List<Transaction>> callback) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = API_BASE_URL + "/transactions?user_id=" + USER_ID;
                    String response = makeGetRequest(url);
                    
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getBoolean("success")) {
                        JSONArray transactionsArray = jsonResponse.getJSONArray("transactions");
                        List<Transaction> transactions = parseTransactionsArray(transactionsArray);
                        callback.onSuccess(transactions);
                    } else {
                        callback.onError(jsonResponse.optString("error", "Erro desconhecido"));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao obter transações", e);
                    callback.onError("Erro de conexão: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Obtém as transações mais recentes
     * 
     * @param limit Número máximo de transações a retornar
     * @param callback Callback para receber o resultado
     */
    public void getRecentTransactions(int limit, ApiCallback<List<Transaction>> callback) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = API_BASE_URL + "/transactions?user_id=" + USER_ID;
                    String response = makeGetRequest(url);
                    
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getBoolean("success")) {
                        JSONArray transactionsArray = jsonResponse.getJSONArray("transactions");
                        List<Transaction> allTransactions = parseTransactionsArray(transactionsArray);
                        
                        // Limita o número de transações retornadas
                        List<Transaction> recentTransactions = new ArrayList<>();
                        int count = Math.min(limit, allTransactions.size());
                        for (int i = 0; i < count; i++) {
                            recentTransactions.add(allTransactions.get(i));
                        }
                        
                        callback.onSuccess(recentTransactions);
                    } else {
                        callback.onError(jsonResponse.optString("error", "Erro desconhecido"));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao obter transações recentes", e);
                    callback.onError("Erro de conexão: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Cria uma nova transação
     * 
     * @param transaction Dados da transação a ser criada
     * @param callback Callback para receber o resultado
     */
    public void createTransaction(Transaction transaction, ApiCallback<Transaction> callback) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = API_BASE_URL + "/transactions";
                    JSONObject requestBody = createTransactionJson(transaction);
                    String response = makePostRequest(url, requestBody.toString());
                    
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getBoolean("success")) {
                        JSONObject transactionJson = jsonResponse.getJSONObject("transaction");
                        Transaction createdTransaction = parseTransactionJson(transactionJson);
                        callback.onSuccess(createdTransaction);
                    } else {
                        callback.onError(jsonResponse.optString("error", "Erro desconhecido"));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao criar transação", e);
                    callback.onError("Erro de conexão: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Atualiza uma transação existente
     * 
     * @param transaction Dados da transação a ser atualizada
     * @param callback Callback para receber o resultado
     */
    public void updateTransaction(Transaction transaction, ApiCallback<Transaction> callback) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = API_BASE_URL + "/transactions/" + transaction.getId();
                    JSONObject requestBody = createTransactionJson(transaction);
                    String response = makePutRequest(url, requestBody.toString());
                    
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getBoolean("success")) {
                        JSONObject transactionJson = jsonResponse.getJSONObject("transaction");
                        Transaction updatedTransaction = parseTransactionJson(transactionJson);
                        callback.onSuccess(updatedTransaction);
                    } else {
                        callback.onError(jsonResponse.optString("error", "Erro desconhecido"));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao atualizar transação", e);
                    callback.onError("Erro de conexão: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Exclui uma transação
     * 
     * @param transactionId ID da transação a ser excluída
     * @param callback Callback para receber o resultado
     */
    public void deleteTransaction(int transactionId, ApiCallback<Void> callback) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = API_BASE_URL + "/transactions/" + transactionId;
                    String response = makeDeleteRequest(url);
                    
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getBoolean("success")) {
                        callback.onSuccess(null);
                    } else {
                        callback.onError(jsonResponse.optString("error", "Erro desconhecido"));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao excluir transação", e);
                    callback.onError("Erro de conexão: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Obtém todas as categorias do usuário
     * 
     * @param callback Callback para receber o resultado
     */
    public void getCategories(ApiCallback<List<Category>> callback) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = API_BASE_URL + "/categories?user_id=" + USER_ID;
                    String response = makeGetRequest(url);
                    
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getBoolean("success")) {
                        JSONArray categoriesArray = jsonResponse.getJSONArray("categories");
                        List<Category> categories = parseCategoriesArray(categoriesArray);
                        callback.onSuccess(categories);
                    } else {
                        callback.onError(jsonResponse.optString("error", "Erro desconhecido"));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao obter categorias", e);
                    callback.onError("Erro de conexão: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Cria uma nova categoria
     * 
     * @param category Dados da categoria a ser criada
     * @param callback Callback para receber o resultado
     */
    public void createCategory(Category category, ApiCallback<Category> callback) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = API_BASE_URL + "/categories";
                    JSONObject requestBody = createCategoryJson(category);
                    String response = makePostRequest(url, requestBody.toString());
                    
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getBoolean("success")) {
                        JSONObject categoryJson = jsonResponse.getJSONObject("category");
                        Category createdCategory = parseCategoryJson(categoryJson);
                        callback.onSuccess(createdCategory);
                    } else {
                        callback.onError(jsonResponse.optString("error", "Erro desconhecido"));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Erro ao criar categoria", e);
                    callback.onError("Erro de conexão: " + e.getMessage());
                }
            }
        });
    }
    
    // Métodos auxiliares para requisições HTTP
    
    /**
     * Executa uma requisição GET
     * 
     * @param urlString URL da requisição
     * @return Resposta da requisição
     * @throws IOException Erro de conexão
     */
    private String makeGetRequest(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Content-Type", "application/json");
        
        return readResponse(connection);
    }
    
    /**
     * Executa uma requisição POST
     * 
     * @param urlString URL da requisição
     * @param requestBody Corpo da requisição em JSON
     * @return Resposta da requisição
     * @throws IOException Erro de conexão
     */
    private String makePostRequest(String urlString, String requestBody) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setDoOutput(true);
        
        // Escreve o corpo da requisição
        try (OutputStream os = connection.getOutputStream()) {
            os.write(requestBody.getBytes("UTF-8"));
        }
        
        return readResponse(connection);
    }
    
    /**
     * Executa uma requisição PUT
     * 
     * @param urlString URL da requisição
     * @param requestBody Corpo da requisição em JSON
     * @return Resposta da requisição
     * @throws IOException Erro de conexão
     */
    private String makePutRequest(String urlString, String requestBody) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("PUT");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setDoOutput(true);
        
        // Escreve o corpo da requisição
        try (OutputStream os = connection.getOutputStream()) {
            os.write(requestBody.getBytes("UTF-8"));
        }
        
        return readResponse(connection);
    }
    
    /**
     * Executa uma requisição DELETE
     * 
     * @param urlString URL da requisição
     * @return Resposta da requisição
     * @throws IOException Erro de conexão
     */
    private String makeDeleteRequest(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("DELETE");
        connection.setRequestProperty("Content-Type", "application/json");
        
        return readResponse(connection);
    }
    
    /**
     * Lê a resposta de uma conexão HTTP
     * 
     * @param connection Conexão HTTP
     * @return Resposta como string
     * @throws IOException Erro de leitura
     */
    private String readResponse(HttpURLConnection connection) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        
        reader.close();
        return response.toString();
    }
    
    // Métodos auxiliares para parsing JSON
    
    /**
     * Converte um array JSON de transações em uma lista de objetos Transaction
     * 
     * @param jsonArray Array JSON de transações
     * @return Lista de transações
     * @throws JSONException Erro de parsing JSON
     */
    private List<Transaction> parseTransactionsArray(JSONArray jsonArray) throws JSONException {
        List<Transaction> transactions = new ArrayList<>();
        
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject transactionJson = jsonArray.getJSONObject(i);
            Transaction transaction = parseTransactionJson(transactionJson);
            transactions.add(transaction);
        }
        
        return transactions;
    }
    
    /**
     * Converte um objeto JSON em um objeto Transaction
     * 
     * @param json Objeto JSON da transação
     * @return Objeto Transaction
     * @throws JSONException Erro de parsing JSON
     */
    private Transaction parseTransactionJson(JSONObject json) throws JSONException {
        Transaction transaction = new Transaction();
        transaction.setId(json.getInt("id"));
        transaction.setUserId(json.getInt("user_id"));
        transaction.setCategoryId(json.getInt("category_id"));
        transaction.setDescription(json.getString("description"));
        transaction.setAmount(json.getDouble("amount"));
        transaction.setType(json.getString("type"));
        transaction.setDate(json.getString("date"));
        transaction.setRecurring(json.optBoolean("is_recurring", false));
        transaction.setRecurringFrequency(json.optString("recurring_frequency", null));
        transaction.setRecurringEndDate(json.optString("recurring_end_date", null));
        transaction.setCategoryName(json.optString("category_name", ""));
        
        return transaction;
    }
    
    /**
     * Converte um array JSON de categorias em uma lista de objetos Category
     * 
     * @param jsonArray Array JSON de categorias
     * @return Lista de categorias
     * @throws JSONException Erro de parsing JSON
     */
    private List<Category> parseCategoriesArray(JSONArray jsonArray) throws JSONException {
        List<Category> categories = new ArrayList<>();
        
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject categoryJson = jsonArray.getJSONObject(i);
            Category category = parseCategoryJson(categoryJson);
            categories.add(category);
        }
        
        return categories;
    }
    
    /**
     * Converte um objeto JSON em um objeto Category
     * 
     * @param json Objeto JSON da categoria
     * @return Objeto Category
     * @throws JSONException Erro de parsing JSON
     */
    private Category parseCategoryJson(JSONObject json) throws JSONException {
        Category category = new Category();
        category.setId(json.getInt("id"));
        category.setUserId(json.getInt("user_id"));
        category.setName(json.getString("name"));
        category.setType(json.getString("type"));
        
        return category;
    }
    
    /**
     * Cria um objeto JSON a partir de um objeto Transaction
     * 
     * @param transaction Objeto Transaction
     * @return Objeto JSON
     * @throws JSONException Erro de criação JSON
     */
    private JSONObject createTransactionJson(Transaction transaction) throws JSONException {
        JSONObject json = new JSONObject();
        json.put("user_id", USER_ID);
        json.put("category_id", transaction.getCategoryId());
        json.put("description", transaction.getDescription());
        json.put("amount", transaction.getAmount());
        json.put("type", transaction.getType());
        json.put("date", transaction.getDate());
        json.put("is_recurring", transaction.isRecurring());
        
        if (transaction.getRecurringFrequency() != null) {
            json.put("recurring_frequency", transaction.getRecurringFrequency());
        }
        
        if (transaction.getRecurringEndDate() != null) {
            json.put("recurring_end_date", transaction.getRecurringEndDate());
        }
        
        return json;
    }
    
    /**
     * Cria um objeto JSON a partir de um objeto Category
     * 
     * @param category Objeto Category
     * @return Objeto JSON
     * @throws JSONException Erro de criação JSON
     */
    private JSONObject createCategoryJson(Category category) throws JSONException {
        JSONObject json = new JSONObject();
        json.put("user_id", USER_ID);
        json.put("name", category.getName());
        json.put("type", category.getType());
        
        return json;
    }
    
    /**
     * Libera os recursos do ApiManager
     */
    public void shutdown() {
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}

